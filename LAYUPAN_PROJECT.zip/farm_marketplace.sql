-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2025 at 04:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farm_marketplace`
--

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `last_message_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `farm_name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`id`, `name`, `farm_name`, `email`, `phone`, `password`, `created_at`) VALUES
(1, 'Jaeron josh  Layupan', 'Layupan\'s Farm', 'jotlayupan@gmail.com', '09380661362', '$2y$10$KVTPXa6Ii6F35XJpEhSPme48vQ.mYdlKTEJ/qZS4KUA5.mmtBB2nq', '2025-11-16 02:27:30'),
(3, 'jotjot manugas gwapo', 'jotjot gulayan', 'juswa@gmail.com', '09878882711', '$2y$10$Cu2SGQB9g/jvCubmf5/neeFZzVc3r/dJUnLzAXXIVtPKaYOTEBwrK', '2025-11-16 02:31:45'),
(5, 'jotjot manugas gwapo', 'jotjot gulayan', 'juwa@gmail.com', '09878882711', '$2y$10$OLwxKi.51Sjixd6PsI3WFuWcQVCMZIKEuJcuRkcEr2UwNBwQQiRYG', '2025-11-16 02:33:54');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sender_type` enum('customer','farmer') NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `customer_phone`, `customer_name`, `farmer_id`, `product_id`, `sender_type`, `message`, `is_read`, `created_at`) VALUES
(8, '09388595221', 'Dagnoy', 1, NULL, 'customer', 'Can i order?', 1, '2025-11-17 02:41:25'),
(9, '09388595221', 'Dagnoy', 1, NULL, 'farmer', 'Yes pila imo sir? kay sagpaon tikag oten', 0, '2025-11-17 02:41:43'),
(10, '12345678901', 'jotsu', 1, NULL, 'customer', '2123', 1, '2025-11-20 02:29:47'),
(11, '12345678901', 'jotsu', 1, NULL, 'farmer', '3223', 0, '2025-11-20 02:29:57'),
(12, '12345678901', 'jotsu', 1, NULL, 'customer', '2123', 1, '2025-11-20 02:30:04'),
(13, '12345678901', 'jotsu', 1, NULL, 'farmer', '223', 1, '2025-11-20 02:33:26'),
(14, '12345678901', 'jotsu', 1, NULL, 'farmer', '223', 1, '2025-11-20 02:35:30'),
(15, '12345678901', 'jotsu', 1, NULL, 'farmer', '1122', 1, '2025-11-20 02:35:34'),
(25, '12345678901', 'jotsu', 1, 8, 'customer', '223', 1, '2025-11-20 02:54:44'),
(26, '12345678901', 'jotsu', 1, 8, 'customer', '334567', 1, '2025-11-20 02:55:02'),
(27, '12345678901', 'jotsu', 1, 8, 'farmer', '2235789', 1, '2025-11-20 02:55:13'),
(28, '12345678901', 'jotsu', 1, 8, 'farmer', 'jots', 1, '2025-11-20 02:55:36'),
(29, '09282828282', '1234', 1, 7, 'customer', '11111', 1, '2025-11-20 08:57:52'),
(30, '09788927386', 'jot', 1, 7, 'customer', '222', 1, '2025-11-20 09:32:15');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `quantity` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'available',
  `sold_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `farmer_id`, `name`, `description`, `price`, `quantity`, `image`, `contact_phone`, `created_at`, `status`, `sold_at`) VALUES
(2, 1, 'Broccoli', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 60, 'uploads/69196b04337c5.webp', '09380661362', '2025-11-16 06:11:16', 'available', '2025-11-16 14:23:53'),
(3, 1, 'Lettuce', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 30, 'uploads/69196e9c1fc83.jpg', '09380661362', '2025-11-16 06:26:36', 'available', NULL),
(4, 1, 'Carrots', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/69196ec9d73a9.jpg', '09380661362', '2025-11-16 06:27:21', 'available', NULL),
(5, 1, 'Potatoes', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/69196f02d8140.jpg', '09380661362', '2025-11-16 06:28:18', 'available', NULL),
(6, 1, 'CauliFlower', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/69197022e0f2e.jpg', '09380661362', '2025-11-16 06:33:06', 'available', NULL),
(7, 1, 'Cabbage', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/6919705ba2e23.jpg', '09380661362', '2025-11-16 06:34:03', 'available', NULL),
(8, 1, 'Eggplant', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/6919709295ba5.jpg', '09380661362', '2025-11-16 06:34:58', 'available', NULL),
(9, 1, 'Bell Pepper/ Atsal', 'Interested in this product? Contact me for more details and the best deals!', 50.00, 50, 'uploads/IMG_691edea735ca75.69382900.jpg', '09380661362', '2025-11-16 06:37:38', 'available', '2025-11-20 17:09:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_conversation` (`farmer_id`,`customer_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_last_message` (`last_message_at`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_conversation` (`customer_phone`,`farmer_id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_unread` (`is_read`,`farmer_id`),
  ADD KEY `idx_farmer_messages` (`farmer_id`,`created_at`),
  ADD KEY `idx_phone_farmer` (`customer_phone`,`farmer_id`,`created_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `farmer_id` (`farmer_id`),
  ADD KEY `idx_sold_products` (`status`,`sold_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `conversations`
--
ALTER TABLE `conversations`
  ADD CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversations_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversations_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
