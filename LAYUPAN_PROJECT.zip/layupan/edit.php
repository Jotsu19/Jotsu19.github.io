<?php
ob_start();
require 'config.php';

if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}

if (!isset($_SESSION['farmer_id'])) {
    header('Location: farmerlogin.php');
    ob_end_flush();
    exit;
}

$farmer_id = $_SESSION['farmer_id'];
$product_id = $_GET['id'] ?? 0;
$err = '';

// FETCH PRODUCT FIRST so image name is available before POST upload
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id=? AND farmer_id=? LIMIT 1");
    $stmt->execute([$product_id, $farmer_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        header('Location: farmerdashboard.php');
        ob_end_flush();
        exit;
    }
} catch (PDOException $e) {
    die('Database error: ' . $e->getMessage());
}


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $qty = floatval($_POST['quantity'] ?? 0);
    $phone = trim($_POST['contact_phone'] ?? '');

    // keep old image unless replaced
    $imagePath = $product['image'];

    // ----------- IMAGE UPLOAD FIX -------------
    if (!empty($_FILES['image']['name'])) {
        $img = $_FILES['image'];
        $ext = strtolower(pathinfo($img['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($ext, $allowed)) {
            $newFile = uniqid('IMG_', true) . '.' . $ext;
            $uploadPath = 'uploads/' . $newFile;  // IMPORTANT: full path saved

            if (move_uploaded_file($img['tmp_name'], $uploadPath)) {
                $imagePath = $uploadPath; // Save full uploads/... path
            } else {
                $err = "Image upload failed.";
            }
        } else {
            $err = "Invalid file type. Only JPG, PNG, GIF allowed.";
        }
    }
    // ----------- END FIX -----------------------

    if ($name && $price > 0 && $qty >= 0 && $phone && !$err) {
        try {
            $stmt = $pdo->prepare("
                UPDATE products 
                SET name=?, description=?, price=?, quantity=?, contact_phone=?, image=?
                WHERE id=? AND farmer_id=?
            ");

            $stmt->execute([
                $name, $desc, $price, $qty, $phone, $imagePath,
                $product_id, $farmer_id
            ]);

            header('Location: farmerdashboard.php');
            ob_end_flush();
            exit;
        } catch (PDOException $e) {
            $err = 'Update failed: ' . $e->getMessage();
        }
    } else {
        if (!$err) $err = 'Please fill all required fields correctly.';
    }
}

// NOW include header
require 'header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">✏️ Edit Product</h4>
                </div>
                <div class="card-body">

                    <?php if ($err): ?>
                        <div class="alert alert-danger">
                            <strong>⚠️ Error:</strong> <?= h($err) ?>
                        </div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Product Name *</label>
                            <input type="text" name="name" class="form-control"
                                   value="<?= h($product['name']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" class="form-control" rows="3"><?= h($product['description']) ?></textarea>
                        </div>

                        <?php if (!empty($product['image'])): ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Current Image:</label><br>
                                <img src="<?= h($product['image']) ?>" alt="Product Image" width="150" class="rounded">
                            </div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Upload New Image</label>
                            <input type="file" name="image" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Price (₱) per kg *</label>
                            <input type="number" name="price" class="form-control"
                                   step="0.01" min="0"
                                   value="<?= $product['price'] ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Quantity (kg) *</label>
                            <input type="number" name="quantity" class="form-control"
                                   step="0.01" min="0"
                                   value="<?= $product['quantity'] ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Contact Phone *</label>
                            <input type="tel" name="contact_phone" class="form-control"
                                   value="<?= h($product['contact_phone']) ?>" required>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">💾 Update Product</button>
                            <a href="farmerdashboard.php" class="btn btn-secondary">❌ Cancel</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
