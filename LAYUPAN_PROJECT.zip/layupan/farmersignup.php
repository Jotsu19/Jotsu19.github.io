<?php
require 'config.php';
require 'header.php';
$err = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
$fname = trim($_POST['first_name'] ?? '');
$lname = trim($_POST['last_name'] ?? '');
$mname = trim($_POST['middle_name'] ?? '');
$farm_name = trim($_POST['farm_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';
if($fname && $lname && $email && $phone && $password){
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT INTO farmers (first_name,last_name,middle_name,farm_name,email,phone,password) VALUES (?,?,?,?,?,?,?)");
try{ $stmt->execute([$fname,$lname,$mname,$farm_name,$email,$phone,$hash]); $_SESSION['farmer_id'] = $pdo->lastInsertId(); header('Location: farmer_dashboard.php'); exit; } catch(Exception $e){ $err = 'Error: ' . $e->getMessage(); }
} else { $err = 'Please fill all required fields.'; }
}
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%);
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 30%, rgba(34, 197, 94, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(22, 163, 74, 0.12) 0%, transparent 50%),
        radial-gradient(circle at 50% 50%, rgba(74, 222, 128, 0.1) 0%, transparent 60%);
    animation: gradientShift 20s ease infinite alternate;
    z-index: 0;
}

body::after {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(rgba(22, 163, 74, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(22, 163, 74, 0.03) 1px, transparent 1px);
    background-size: 50px 50px;
    z-index: 0;
}

@keyframes gradientShift {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}

.signup-container {
    max-width: 560px;
    margin: 60px auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.signup-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 24px;
    box-shadow: 
        0 20px 60px rgba(0, 0, 0, 0.15),
        0 0 0 1px rgba(255, 255, 255, 0.5) inset;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.signup-card:hover {
    transform: translateY(-5px);
    box-shadow: 
        0 30px 80px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.5) inset;
}

.signup-header {
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    color: white;
    padding: 40px 32px 36px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.signup-header::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    animation: pulse 4s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.1); opacity: 0.8; }
}

.signup-header h3 {
    margin: 0 0 10px 0;
    font-size: 28px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    position: relative;
    z-index: 1;
    letter-spacing: -0.5px;
}

.icon-wrapper {
    width: 48px;
    height: 48px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    animation: iconFloat 3s ease-in-out infinite;
}

@keyframes iconFloat {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
}

.signup-subheading {
    margin: 0;
    font-size: 15px;
    opacity: 0.95;
    position: relative;
    z-index: 1;
    font-weight: 400;
}

.signup-body {
    padding: 40px 36px;
}

.error-alert {
    background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
    border-left: 4px solid #fc8181;
    color: #c53030;
    padding: 14px 18px;
    border-radius: 12px;
    margin-bottom: 28px;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 4px 12px rgba(229, 62, 62, 0.15);
    animation: shake 0.5s ease;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

.signup-form .form-group {
    margin-bottom: 22px;
    position: relative;
    animation: slideIn 0.4s ease-out backwards;
}

.signup-form .form-group:nth-child(1) { animation-delay: 0.05s; }
.signup-form .form-group:nth-child(2) { animation-delay: 0.1s; }
.signup-form .form-group:nth-child(3) { animation-delay: 0.15s; }
.signup-form .form-group:nth-child(4) { animation-delay: 0.2s; }
.signup-form .form-group:nth-child(5) { animation-delay: 0.25s; }
.signup-form .form-group:nth-child(6) { animation-delay: 0.3s; }
.signup-form .form-group:nth-child(7) { animation-delay: 0.35s; }

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.signup-form label {
    display: block;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 10px;
    font-size: 14px;
    letter-spacing: 0.3px;
}

.required-indicator {
    color: #fc8181;
    margin-left: 3px;
    font-weight: 700;
}

.optional-indicator {
    color: #a0aec0;
    font-weight: 500;
    font-size: 12px;
    margin-left: 6px;
    background: #f7fafc;
    padding: 2px 8px;
    border-radius: 6px;
}

.field-hint {
    display: block;
    font-weight: 400;
    color: #718096;
    font-size: 12px;
    margin-top: 8px;
    padding-left: 4px;
    line-height: 1.5;
}

.signup-form input {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    font-size: 15px;
    transition: all 0.3s ease;
    box-sizing: border-box;
    background: white;
    font-family: inherit;
}

.signup-form input:hover {
    border-color: #cbd5e0;
}

.signup-form input:focus {
    outline: none;
    border-color: #16a34a;
    box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.1);
    transform: translateY(-2px);
}

.signup-form input::placeholder {
    color: #a0aec0;
}

.signup-button {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(22, 163, 74, 0.4);
    position: relative;
    overflow: hidden;
    letter-spacing: 0.5px;
    margin-top: 12px;
}

.signup-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}

.signup-button:hover::before {
    left: 100%;
}

.signup-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 28px rgba(22, 163, 74, 0.5);
}

.signup-button:active {
    transform: translateY(-1px);
    box-shadow: 0 6px 16px rgba(22, 163, 74, 0.4);
}

.login-prompt {
    text-align: center;
    margin-top: 28px;
    padding-top: 28px;
    border-top: 2px solid #e2e8f0;
    color: #4a5568;
    font-size: 14px;
}

.login-prompt a {
    color: #16a34a;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.2s;
    position: relative;
}

.login-prompt a::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 0;
    height: 2px;
    background: #16a34a;
    transition: width 0.3s ease;
}

.login-prompt a:hover::after {
    width: 100%;
}

.login-prompt a:hover {
    color: #15803d;
}

/* Form sections */
.form-section {
    margin-bottom: 32px;
    padding-bottom: 24px;
    border-bottom: 1px solid #e2e8f0;
}

.form-section:last-of-type {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.section-title {
    font-size: 13px;
    font-weight: 600;
    color: #16a34a;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Decorative elements */
.decorative-circle {
    position: fixed;
    border-radius: 50%;
    opacity: 0.1;
    pointer-events: none;
    z-index: 0;
}

.circle-1 {
    width: 300px;
    height: 300px;
    background: linear-gradient(135deg, #16a34a, #15803d);
    top: -100px;
    right: -100px;
    animation: float 20s ease-in-out infinite;
}

.circle-2 {
    width: 200px;
    height: 200px;
    background: linear-gradient(135deg, #4ade80, #22c55e);
    bottom: -50px;
    left: -50px;
    animation: float 15s ease-in-out infinite reverse;
}

@keyframes float {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    33% { transform: translate(30px, -30px) rotate(120deg); }
    66% { transform: translate(-20px, 20px) rotate(240deg); }
}

@media (max-width: 580px) {
    .signup-container {
        margin: 30px auto;
    }
    
    .signup-header {
        padding: 32px 24px 28px;
    }
    
    .signup-header h3 {
        font-size: 24px;
    }
    
    .signup-body {
        padding: 32px 24px;
    }
    
    .icon-wrapper {
        width: 40px;
        height: 40px;
        font-size: 20px;
    }
}
</style>

<div class="decorative-circle circle-1"></div>
<div class="decorative-circle circle-2"></div>

<div class="signup-container">
    <div class="signup-card">
        <div class="signup-header">
            <h3>
                <div class="icon-wrapper">🌾</div>
                <span>Farmer Signup</span>
            </h3>
            <p class="signup-subheading">Create your account to start listing products</p>
        </div>
        
        <div class="signup-body">
            <?php if($err): ?>
                <div class="error-alert">
                    <span>⚠️</span>
                    <span><?=h($err)?></span>
                </div>
            <?php endif; ?>
            
            <form method="post" class="signup-form">
                <div class="form-group">
                    <label>
                        First Name<span class="required-indicator">*</span>
                    </label>
                    <input type="text" name="first_name" placeholder="John" required>
                </div>
                
                <div class="form-group">
                    <label>
                        Last Name<span class="required-indicator">*</span>
                    </label>
                    <input type="text" name="last_name" placeholder="Doe" required>
                </div>
                
                <div class="form-group">
                    <label>
                        Middle Name<span class="optional-indicator">optional</span>
                    </label>
                    <input type="text" name="middle_name" placeholder="M.">
                </div>
                
                <div class="form-group">
                    <label>
                        Farm Name<span class="optional-indicator">optional</span>
                    </label>
                    <input type="text" name="farm_name" placeholder="Sunny Acres Farm">
                </div>
                
                <div class="form-group">
                    <label>
                        Email Address<span class="required-indicator">*</span>
                    </label>
                    <input type="email" name="email" placeholder="your@email.com" required>
                </div>
                
                <div class="form-group">
                    <label>
                        Phone Number<span class="required-indicator">*</span>
                    </label>
                    <input type="tel" name="phone" placeholder="+63 912 345 6789" required>
                    <span class="field-hint">📞 This will be shown to customers for direct contact</span>
                </div>
                
                <div class="form-group">
                    <label>
                        Password<span class="required-indicator">*</span>
                    </label>
                    <input type="password" name="password" placeholder="Create a strong password" required>
                </div>
                
                <button type="submit" class="signup-button">Create Account</button>
            </form>
            
            <div class="login-prompt">
                Already have an account? <a href="farmerlogin.php">Log in</a>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>