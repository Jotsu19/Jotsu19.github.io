<?php
require 'config.php';
require 'header.php';
$action = $_GET['action'] ?? 'home';


if($_SERVER['REQUEST_METHOD'] === 'POST'){
if(isset($_POST['logout'])){ session_destroy(); header('Location: index.php'); exit; }
}


if($action === 'home'){
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

/* Background container */
body {
    margin: 0;
    min-height: 100vh;
    position: relative;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    overflow-x: hidden;
}

.page-background {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 50%, #dcedc8 100%);
    z-index: -2;
}

.page-background::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: 
        radial-gradient(circle at 20% 80%, rgba(76, 175, 80, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(129, 199, 132, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 40% 40%, rgba(102, 187, 106, 0.1) 0%, transparent 40%);
    animation: backgroundPulse 8s ease-in-out infinite;
}

@keyframes backgroundPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
}

/* Animated floating vegetables */
.floating-icons {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: -1;
}

.float-icon {
    position: absolute;
    font-size: 40px;
    opacity: 0.2;
    animation: floatAround 20s ease-in-out infinite;
}

.float-icon:nth-child(1) { left: 10%; top: 15%; animation-delay: 0s; animation-duration: 18s; }
.float-icon:nth-child(2) { left: 80%; top: 25%; animation-delay: 2s; animation-duration: 22s; }
.float-icon:nth-child(3) { left: 15%; top: 70%; animation-delay: 4s; animation-duration: 20s; }
.float-icon:nth-child(4) { left: 85%; top: 65%; animation-delay: 6s; animation-duration: 24s; }
.float-icon:nth-child(5) { left: 50%; top: 10%; animation-delay: 8s; animation-duration: 19s; }
.float-icon:nth-child(6) { left: 25%; top: 45%; animation-delay: 3s; animation-duration: 21s; }
.float-icon:nth-child(7) { left: 70%; top: 80%; animation-delay: 5s; animation-duration: 23s; }
.float-icon:nth-child(8) { left: 40%; top: 85%; animation-delay: 7s; animation-duration: 17s; }

@keyframes floatAround {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    25% { transform: translate(30px, -30px) rotate(90deg); }
    50% { transform: translate(0, -50px) rotate(180deg); }
    75% { transform: translate(-30px, -20px) rotate(270deg); }
}

.hero-container {
    max-width: 540px;
    margin: 80px auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
    animation: fadeInUp 0.8s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(40px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.welcome-card {
    background: #ffffff;
    backdrop-filter: blur(20px);
    border-radius: 28px;
    padding: 56px 48px;
    box-shadow: 
        0 20px 60px rgba(76, 175, 80, 0.2),
        0 0 0 1px rgba(76, 175, 80, 0.1) inset;
    text-align: center;
    border: 3px solid #4caf50;
    position: relative;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.welcome-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 6px;
    background: linear-gradient(90deg, #4caf50 0%, #66bb6a 25%, #81c784 50%, #66bb6a 75%, #4caf50 100%);
    background-size: 200% 100%;
    animation: shimmer 3s ease-in-out infinite;
}

@keyframes shimmer {
    0%, 100% { background-position: 0% 0%; }
    50% { background-position: 100% 0%; }
}

.welcome-card:hover {
    transform: translateY(-8px);
    box-shadow: 
        0 30px 80px rgba(76, 175, 80, 0.3),
        0 0 0 1px rgba(76, 175, 80, 0.2) inset;
    border-color: #43a047;
}

.welcome-icon {
    width: 90px;
    height: 90px;
    margin: 0 auto 24px;
    background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
    border-radius: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 45px;
    box-shadow: 
        0 10px 30px rgba(76, 175, 80, 0.4),
        0 0 0 4px rgba(255, 255, 255, 0.5),
        0 0 0 6px rgba(76, 175, 80, 0.3);
    animation: iconBounce 2s ease-in-out infinite;
    position: relative;
    z-index: 1;
}

@keyframes iconBounce {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-10px) scale(1.05); }
}

.welcome-card h3 {
    font-size: 34px;
    font-weight: 800;
    background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0 0 12px 0;
    position: relative;
    z-index: 1;
    letter-spacing: -0.5px;
}

.welcome-card p {
    color: #558b2f;
    font-size: 17px;
    margin: 0 0 36px 0;
    position: relative;
    z-index: 1;
    font-weight: 600;
}

.button-group {
    display: flex;
    gap: 16px;
    justify-content: center;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
}

.user-button {
    flex: 1;
    min-width: 160px;
    padding: 20px 32px;
    border-radius: 16px;
    text-decoration: none;
    font-weight: 700;
    font-size: 18px;
    transition: all 0.3s ease;
    box-shadow: 0 8px 25px rgba(76, 175, 80, 0.3);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    position: relative;
    overflow: hidden;
    letter-spacing: 0.5px;
    border: 3px solid transparent;
}

.user-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    transition: left 0.5s;
}

.user-button:hover::before {
    left: 100%;
}

.user-button.farmer {
    background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
    color: white;
    border-color: #2e7d32;
}

.user-button.customer {
    background: linear-gradient(135deg, #66bb6a 0%, #81c784 100%);
    color: white;
    border-color: #43a047;
}

.user-button:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow: 0 15px 40px rgba(76, 175, 80, 0.45);
}

.user-button.farmer:hover {
    background: linear-gradient(135deg, #43a047 0%, #5cb860 100%);
}

.user-button.customer:hover {
    background: linear-gradient(135deg, #5cb860 0%, #72c47a 100%);
}

.user-button:active {
    transform: translateY(-2px) scale(1);
}

.user-button span {
    font-size: 24px;
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
}

.info-note {
    text-align: center;
    color: #2e7d32;
    font-size: 15px;
    line-height: 1.7;
    margin-top: 28px;
    padding: 24px 28px;
    background: #ffffff;
    backdrop-filter: blur(20px);
    border-radius: 20px;
    border: 3px solid #4caf50;
    border-left: 6px solid #2e7d32;
    box-shadow: 0 10px 35px rgba(76, 175, 80, 0.2);
    animation: fadeInUp 0.8s ease-out 0.3s backwards;
    position: relative;
    overflow: hidden;
    font-weight: 500;
}

.info-note::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 6px;
    height: 100%;
    background: linear-gradient(180deg, #2e7d32 0%, #4caf50 50%, #66bb6a 100%);
    box-shadow: 0 0 15px rgba(76, 175, 80, 0.6);
}

.info-note strong {
    color: #1b5e20;
    font-weight: 800;
}

/* Decorative circles */
.decorative-circle {
    position: fixed;
    border-radius: 50%;
    opacity: 0.12;
    pointer-events: none;
    z-index: 0;
}

.circle-1 {
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(76, 175, 80, 0.3) 0%, transparent 70%);
    top: -200px;
    right: -200px;
    animation: circleFloat 25s ease-in-out infinite;
    border: 3px solid rgba(76, 175, 80, 0.2);
}

.circle-2 {
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(129, 199, 132, 0.3) 0%, transparent 70%);
    bottom: -150px;
    left: -150px;
    animation: circleFloat 20s ease-in-out infinite reverse;
    border: 3px solid rgba(129, 199, 132, 0.2);
}

.circle-3 {
    width: 250px;
    height: 250px;
    background: radial-gradient(circle, rgba(102, 187, 106, 0.2) 0%, transparent 70%);
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    animation: circlePulse 15s ease-in-out infinite;
    border: 2px solid rgba(102, 187, 106, 0.2);
}

@keyframes circleFloat {
    0%, 100% { transform: translate(0, 0) scale(1); }
    33% { transform: translate(50px, -50px) scale(1.1); }
    66% { transform: translate(-40px, 40px) scale(0.9); }
}

@keyframes circlePulse {
    0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.12; }
    50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.18; }
}

@media (max-width: 580px) {
    .hero-container {
        margin: 50px auto;
    }
    
    .button-group {
        flex-direction: column;
    }
    
    .user-button {
        width: 100%;
    }
    
    .welcome-card {
        padding: 40px 28px;
        border-width: 2px;
    }
    
    .welcome-card h3 {
        font-size: 28px;
    }
    
    .welcome-icon {
        width: 75px;
        height: 75px;
        font-size: 38px;
    }
}
</style>

<!-- Background with floating icons -->
<div class="page-background"></div>
<div class="floating-icons">
    <div class="float-icon">🥬</div>
    <div class="float-icon">🥕</div>
    <div class="float-icon">🌽</div>
    <div class="float-icon">🍅</div>
    <div class="float-icon">🥦</div>
    <div class="float-icon">🥒</div>
    <div class="float-icon">🌶️</div>
    <div class="float-icon">🧅</div>
</div>
<div class="decorative-circle circle-1"></div>
<div class="decorative-circle circle-2"></div>
<div class="decorative-circle circle-3"></div>

<div class="hero-container">
    <div class="welcome-card">
        <div class="welcome-icon">🌱</div>
        <h3>Choose User Type</h3>
        <p>Select your role to continue</p>
        <div class="button-group">
            <a href="farmerlogin.php" class="user-button farmer">
                <span>🌾</span> Farmer
            </a>
            <a href="customersdashboard.php" class="user-button customer">
                <span>🛒</span> Customer
            </a>
        </div>
    </div>
    <div class="info-note">
        <strong>📝 Note:</strong> Farmers must create an account to list products. Customers can browse without signing up.
    </div>
</div>
<?php
}


require 'footer.php';
?>