<?php
ob_start(); // Add output buffering
require 'config.php';
require 'header.php';

// Helper function in case it's not in config.php
if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}

$err = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if(empty($email) || empty($password)) {
        $err = 'Please enter both email and password.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM farmers WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $farmer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if($farmer && password_verify($password, $farmer['password'])) { 
                $_SESSION['farmer_id'] = $farmer['id']; 
                header('Location: farmerdashboard.php'); 
                ob_end_flush();
                exit; 
            } else { 
                $err = 'Invalid email or password.'; 
            }
        } catch(PDOException $e) {
            $err = 'Database error. Please try again.';
            // For debugging (remove in production):
            // $err = 'Error: ' . $e->getMessage();
        }
    }
}
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%);
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 30%, rgba(34, 197, 94, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(22, 163, 74, 0.12) 0%, transparent 50%),
        radial-gradient(circle at 50% 50%, rgba(74, 222, 128, 0.1) 0%, transparent 60%);
    animation: gradientShift 20s ease infinite alternate;
    z-index: 0;
}

body::after {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: 
        linear-gradient(rgba(22, 163, 74, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(22, 163, 74, 0.03) 1px, transparent 1px);
    background-size: 50px 50px;
    z-index: 0;
}

@keyframes gradientShift {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}

.login-container {
    max-width: 460px;
    margin: 80px auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.login-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 24px;
    box-shadow: 
        0 20px 60px rgba(0, 0, 0, 0.15),
        0 0 0 1px rgba(255, 255, 255, 0.5) inset;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.login-card:hover {
    transform: translateY(-5px);
    box-shadow: 
        0 30px 80px rgba(0, 0, 0, 0.2),
        0 0 0 1px rgba(255, 255, 255, 0.5) inset;
}

.login-header {
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    color: white;
    padding: 40px 32px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.login-header::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    animation: pulse 4s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.1); opacity: 0.8; }
}

.login-header h3 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    position: relative;
    z-index: 1;
    letter-spacing: -0.5px;
}

.icon-wrapper {
    width: 48px;
    height: 48px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    animation: iconFloat 3s ease-in-out infinite;
}

@keyframes iconFloat {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
}

.login-body {
    padding: 40px 36px;
}

.error-alert {
    background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
    border-left: 4px solid #fc8181;
    color: #c53030;
    padding: 14px 18px;
    border-radius: 12px;
    margin-bottom: 28px;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 4px 12px rgba(229, 62, 62, 0.15);
    animation: shake 0.5s ease;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

.login-form .form-group {
    margin-bottom: 24px;
    position: relative;
}

.login-form label {
    display: block;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 10px;
    font-size: 14px;
    letter-spacing: 0.3px;
    transition: color 0.2s;
}

.login-form input {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    font-size: 15px;
    transition: all 0.3s ease;
    box-sizing: border-box;
    background: white;
    font-family: inherit;
}

.login-form input:hover {
    border-color: #cbd5e0;
}

.login-form input:focus {
    outline: none;
    border-color: #16a34a;
    box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.1);
    transform: translateY(-2px);
}

.login-form input::placeholder {
    color: #a0aec0;
}

.login-button {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 8px 20px rgba(22, 163, 74, 0.4);
    position: relative;
    overflow: hidden;
    letter-spacing: 0.5px;
    margin-top: 8px;
}

.login-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}

.login-button:hover::before {
    left: 100%;
}

.login-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 28px rgba(22, 163, 74, 0.5);
}

.login-button:active {
    transform: translateY(-1px);
    box-shadow: 0 6px 16px rgba(22, 163, 74, 0.4);
}

.signup-prompt {
    text-align: center;
    margin-top: 28px;
    padding-top: 28px;
    border-top: 2px solid #e2e8f0;
    color: #4a5568;
    font-size: 14px;
}

.signup-prompt a {
    color: #16a34a;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.2s;
    position: relative;
}

.signup-prompt a::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 0;
    height: 2px;
    background: #16a34a;
    transition: width 0.3s ease;
}

.signup-prompt a:hover::after {
    width: 100%;
}

.signup-prompt a:hover {
    color: #15803d;
}

/* Decorative elements */
.decorative-circle {
    position: fixed;
    border-radius: 50%;
    opacity: 0.1;
    pointer-events: none;
    z-index: 0;
}

.circle-1 {
    width: 300px;
    height: 300px;
    background: linear-gradient(135deg, #16a34a, #15803d);
    top: -100px;
    right: -100px;
    animation: float 20s ease-in-out infinite;
}

.circle-2 {
    width: 200px;
    height: 200px;
    background: linear-gradient(135deg, #4ade80, #22c55e);
    bottom: -50px;
    left: -50px;
    animation: float 15s ease-in-out infinite reverse;
}

@keyframes float {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    33% { transform: translate(30px, -30px) rotate(120deg); }
    66% { transform: translate(-20px, 20px) rotate(240deg); }
}

@media (max-width: 480px) {
    .login-container {
        margin: 40px auto;
    }
    
    .login-header {
        padding: 32px 24px;
    }
    
    .login-header h3 {
        font-size: 24px;
    }
    
    .login-body {
        padding: 32px 24px;
    }
    
    .icon-wrapper {
        width: 40px;
        height: 40px;
        font-size: 20px;
    }
}
</style>

<div class="decorative-circle circle-1"></div>
<div class="decorative-circle circle-2"></div>

<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <h3>
                <div class="icon-wrapper">🌾</div>
                <span>Farmer Login</span>
            </h3>
        </div>
        
        <div class="login-body">
            <?php if($err): ?>
                <div class="error-alert">
                    <span>⚠️</span>
                    <span><?php echo h($err); ?></span>
                </div>
            <?php endif; ?>
            
            <form method="post" class="login-form">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="your@email.com" required>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>
                
                <button type="submit" class="login-button">Log In</button>
            </form>
            
            <div class="signup-prompt">
                Don't have an account? <a href="farmersignup.php">Sign up here</a>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>