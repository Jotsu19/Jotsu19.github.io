<!-- Replace the chat button section in browse.php with this: -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
    <a href="tel:<?=h($p['contact_phone'])?>" class="contact-button" style="padding: 10px;">
        <span>📞</span>
        <span>Call</span>
    </a>
    <a href="chat.php?farmer_id=<?=h($p['farmer_id'])?>&product_id=<?=h($p['id'])?>" class="contact-button" style="padding: 10px; background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);">
        <span>💬</span>
        <span>Chat</span>
    </a>
</div>