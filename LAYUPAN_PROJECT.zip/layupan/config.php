<?php
// Database configuration
$DB_HOST = '127.0.0.1';
$DB_NAME = 'farm_marketplace';
$DB_USER = 'root';
$DB_PASS = '';


try {
$pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
} catch (Exception $e) {
die('DB Connection failed: ' . htmlspecialchars($e->getMessage()));
}


session_start();
function h($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function is_logged(){ return !empty($_SESSION['farmer_id']); }
?>