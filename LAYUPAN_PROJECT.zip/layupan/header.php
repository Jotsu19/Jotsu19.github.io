<?php
// Handle logout if submitted BEFORE any output
if(isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JOTJOT's Farm Fresh Market</title>

<!-- Bootstrap v5 CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
* {
  font-family: 'Poppins', sans-serif;
}

body {
  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%);
  min-height: 100vh;
  position: relative;
}

body::before {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: 
    radial-gradient(circle at 20% 80%, rgba(34, 197, 94, 0.08) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(22, 163, 74, 0.08) 0%, transparent 50%);
  pointer-events: none;
  z-index: 0;
}

body::after {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: 
    linear-gradient(rgba(22, 163, 74, 0.02) 1px, transparent 1px),
    linear-gradient(90deg, rgba(22, 163, 74, 0.02) 1px, transparent 1px);
  background-size: 50px 50px;
  z-index: 0;
  pointer-events: none;
}

/* Enhanced Navbar */
.navbar {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%) !important;
  box-shadow: 0 4px 20px rgba(22, 163, 74, 0.3);
  padding: 1.2rem 0;
  border-bottom: 3px solid #14532d;
  position: relative;
  z-index: 10;
}

.navbar::after {
  content: '';
  position: absolute;
  bottom: -3px;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #14532d 0%, #22c55e 50%, #14532d 100%);
  background-size: 200% 100%;
  animation: navShimmer 3s linear infinite;
}

@keyframes navShimmer {
  0% { background-position: 0% 0%; }
  100% { background-position: 200% 0%; }
}

.navbar-brand {
  font-size: 1.5rem;
  font-weight: 800;
  letter-spacing: 0.3px;
  color: #ffffff !important;
  transition: all 0.3s ease;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
  position: relative;
}

.navbar-brand::before {
  content: '🌾';
  margin-right: 10px;
  font-size: 1.7rem;
  display: inline-block;
  animation: iconBounce 2s ease-in-out infinite;
}

@keyframes iconBounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

.navbar-brand:hover {
  transform: scale(1.05);
  color: #d1fae5 !important;
  text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.3);
}

/* Enhanced Home Button */
.btn-light {
  background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
  color: #15803d;
  border: 2px solid #86efac;
  padding: 0.65rem 2rem;
  border-radius: 25px;
  font-weight: 700;
  box-shadow: 0 4px 12px rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
  letter-spacing: 0.5px;
  position: relative;
  overflow: hidden;
}

.btn-light::before {
  content: '🏠';
  margin-right: 8px;
  font-size: 1.1rem;
}

.btn-light::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background: rgba(22, 163, 74, 0.2);
  transform: translate(-50%, -50%);
  transition: width 0.5s, height 0.5s;
}

.btn-light:hover::after {
  width: 300px;
  height: 300px;
}

.btn-light:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 20px rgba(22, 163, 74, 0.4);
  background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
  color: #14532d;
  border-color: #22c55e;
}

.btn-light:active {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(22, 163, 74, 0.3);
}

/* Container Enhancement */
.container {
  position: relative;
  z-index: 1;
  animation: fadeIn 0.6s ease;
  padding-top: 2rem;
  padding-bottom: 2rem;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Product Image Styles */
.product img {
  max-width: 150px;
  max-height: 120px;
  object-fit: cover;
  border-radius: 12px;
  border: 3px solid #bbf7d0;
  box-shadow: 0 4px 15px rgba(22, 163, 74, 0.15);
  transition: all 0.3s ease;
}

.product:hover img {
  transform: scale(1.08) rotate(2deg);
  border-color: #4ade80;
  box-shadow: 0 8px 25px rgba(22, 163, 74, 0.25);
}

/* Product Card Enhancement */
.product {
  background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 6px 20px rgba(22, 163, 74, 0.1);
  transition: all 0.3s ease;
  border: 2px solid #dcfce7;
  position: relative;
  overflow: hidden;
}

.product::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 4px;
  height: 100%;
  background: linear-gradient(180deg, #22c55e 0%, #16a34a 100%);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.product:hover::before {
  opacity: 1;
}

.product:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 35px rgba(22, 163, 74, 0.2);
  border-color: #86efac;
  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

/* Card Styles */
.card {
  border: 2px solid #dcfce7;
  border-radius: 16px;
  box-shadow: 0 6px 20px rgba(22, 163, 74, 0.1);
  transition: all 0.3s ease;
  background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 12px 30px rgba(22, 163, 74, 0.18);
  border-color: #86efac;
}

.card-header {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
  color: #ffffff;
  font-weight: 700;
  border-radius: 14px 14px 0 0 !important;
  padding: 1rem 1.5rem;
  border-bottom: 3px solid #14532d;
}

/* Button Enhancements */
.btn-success {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
  border: 2px solid #14532d;
  border-radius: 12px;
  padding: 0.8rem 1.5rem;
  font-weight: 700;
  transition: all 0.3s ease;
  box-shadow: 0 6px 18px rgba(22, 163, 74, 0.3);
  letter-spacing: 0.3px;
}

.btn-success:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(22, 163, 74, 0.4);
  background: linear-gradient(135deg, #15803d 0%, #14532d 100%);
}

.btn-danger {
  border-radius: 12px;
  padding: 0.8rem 1.5rem;
  font-weight: 700;
  transition: all 0.3s ease;
}

.btn-danger:hover {
  transform: translateY(-3px);
  box-shadow: 0 8px 20px rgba(220, 38, 38, 0.3);
}

/* Form Controls */
.form-control, .form-select {
  border-radius: 10px;
  border: 2px solid #dcfce7;
  padding: 0.8rem 1rem;
  transition: all 0.3s ease;
  background: white;
}

.form-control:hover, .form-select:hover {
  border-color: #bbf7d0;
}

.form-control:focus, .form-select:focus {
  border-color: #16a34a;
  box-shadow: 0 0 0 0.25rem rgba(22, 163, 74, 0.15);
  background: white;
  transform: translateY(-2px);
}

/* Table Styles */
.table {
  border-radius: 12px;
  overflow: hidden;
  border: 2px solid #dcfce7;
  background: white;
}

.table thead {
  background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
  color: white;
}

.table thead th {
  padding: 1rem;
  font-weight: 700;
  border: none;
}

.table tbody tr {
  transition: all 0.2s ease;
}

.table tbody tr:hover {
  background: linear-gradient(to right, #f0fdf4, #dcfce7);
  transform: scale(1.01);
}

.table tbody td {
  padding: 1rem;
  vertical-align: middle;
}

/* Alert Styles */
.alert {
  border-radius: 12px;
  border: 2px solid #16a34a;
  box-shadow: 0 4px 15px rgba(22, 163, 74, 0.1);
  padding: 1rem 1.25rem;
}

.alert-success {
  background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
  color: #14532d;
  border-left: 5px solid #16a34a;
}

.alert-danger {
  background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
  color: #991b1b;
  border-left: 5px solid #dc2626;
  border-color: #dc2626;
}

/* Responsive Design */
@media (max-width: 768px) {
  .navbar-brand {
    font-size: 1.2rem;
  }
  
  .navbar-brand::before {
    font-size: 1.4rem;
  }
  
  .btn-light {
    padding: 0.5rem 1.2rem;
    font-size: 0.9rem;
  }
  
  .container {
    padding-left: 1rem;
    padding-right: 1rem;
  }
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
<div class="container-fluid px-4">
<a class="navbar-brand" href="index.php">
  Farm Vegetable Marketplace
</a>

<div class="d-flex">
<?php if(is_logged()): ?>
<form method="post" style="display: inline;">
  <button type="submit" name="logout" class="btn btn-light btn-sm">
    🚪 Logout
  </button>
</form>
<?php else: ?>
<a href="index.php" class="btn btn-light btn-sm">Home</a>
<?php endif; ?>
</div>
</div>
</nav>
<div class="container mt-4">