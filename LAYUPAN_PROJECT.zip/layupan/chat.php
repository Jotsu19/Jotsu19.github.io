<?php
require 'config.php';

$farmer_id = $_GET['farmer_id'] ?? null;
$product_id = $_GET['product_id'] ?? null;

if (!$farmer_id) {
    header('Location: browse.php');
    exit;
}

// Get farmer details
$stmt = $pdo->prepare("SELECT * FROM farmers WHERE id = ?");
$stmt->execute([$farmer_id]);
$farmer = $stmt->fetch();

if (!$farmer) {
    die("Farmer not found");
}

// Get product details if product_id is provided
$product = null;
if ($product_id) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND farmer_id = ?");
    $stmt->execute([$product_id, $farmer_id]);
    $product = $stmt->fetch();
}

// Handle all POST requests BEFORE including header.php
$customer_phone = $_SESSION['customer_phone'] ?? '';
$customer_name = $_SESSION['customer_name'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['start_chat'])) {
        // Starting chat - save phone and name to session
        $customer_phone = trim($_POST['customer_phone']);
        $customer_name = trim($_POST['customer_name']);
        
        if (!empty($customer_phone) && !empty($customer_name)) {
            $_SESSION['customer_phone'] = $customer_phone;
            $_SESSION['customer_name'] = $customer_name;
            // Redirect to refresh the page with session data
            header("Location: chat.php?farmer_id=$farmer_id" . ($product_id ? "&product_id=$product_id" : ""));
            exit;
        }
    } elseif (isset($_POST['change_phone'])) {
        // Clear session and reload
        unset($_SESSION['customer_phone']);
        unset($_SESSION['customer_name']);
        header("Location: chat.php?farmer_id=$farmer_id" . ($product_id ? "&product_id=$product_id" : ""));
        exit;
    } elseif (isset($_POST['message'])) {
        // Sending message
        $message = trim($_POST['message']);
        $customer_phone = $_SESSION['customer_phone'] ?? '';
        $customer_name = $_SESSION['customer_name'] ?? '';
        
        if (!empty($message) && !empty($customer_phone) && !empty($customer_name)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO messages (customer_phone, customer_name, farmer_id, sender_type, message, product_id, is_read, created_at) 
                    VALUES (?, ?, ?, 'customer', ?, ?, 0, NOW())
                ");
                $stmt->execute([$customer_phone, $customer_name, $farmer_id, $message, $product_id]);
                
                // Redirect to prevent form resubmission
                header("Location: chat.php?farmer_id=$farmer_id" . ($product_id ? "&product_id=$product_id" : ""));
                exit;
            } catch (PDOException $e) {
                $error_message = "Error sending message: " . $e->getMessage();
            }
        }
    }
}

// Now include header after all redirects are done
require 'header.php';

// Get all messages for this phone number and farmer
$messages = [];
if (!empty($customer_phone)) {
    $stmt = $pdo->prepare("
        SELECT m.*, 
               f.name as farmer_name,
               p.name as product_name
        FROM messages m
        LEFT JOIN farmers f ON m.farmer_id = f.id
        LEFT JOIN products p ON m.product_id = p.id
        WHERE m.customer_phone = ? AND m.farmer_id = ?
        ORDER BY m.created_at ASC
    ");
    $stmt->execute([$customer_phone, $farmer_id]);
    $messages = $stmt->fetchAll();
}

// Check if user needs to enter phone number
$needs_phone = empty($customer_phone) || empty($customer_name);

// Helper function for HTML escaping
if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}
?>

<style>
body {
    margin: 0;
    background: linear-gradient(to bottom, #e8f5e9 0%, #f1f8f4 50%, #fff8e1 100%);
    min-height: 100vh;
}

.chat-container {
    max-width: 900px;
    margin: 20px auto;
    padding: 0 20px;
    height: calc(100vh - 140px);
    display: flex;
    flex-direction: column;
}

.chat-header {
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    padding: 20px 24px;
    border-radius: 12px 12px 0 0;
    box-shadow: 0 2px 8px rgba(106, 168, 79, 0.2);
}

.chat-header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}

.farmer-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.farmer-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.farmer-details h3 {
    margin: 0 0 4px 0;
    font-size: 20px;
    font-weight: 600;
}

.farmer-details p {
    margin: 0;
    opacity: 0.9;
    font-size: 14px;
}

.header-actions {
    display: flex;
    gap: 8px;
}

.action-button {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    padding: 8px 16px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 6px;
    border: none;
    cursor: pointer;
}

.action-button:hover {
    background: rgba(255, 255, 255, 0.3);
}

.product-context {
    background: rgba(255, 255, 255, 0.15);
    padding: 12px 16px;
    border-radius: 8px;
    margin-top: 12px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
}

.chat-messages {
    flex: 1;
    background: white;
    padding: 24px;
    overflow-y: auto;
    border-left: 2px solid #e8f5e9;
    border-right: 2px solid #e8f5e9;
}

/* Customer Login Screen Styles */
.login-screen {
    flex: 1;
    background: white;
    padding: 40px 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-left: 2px solid #e8f5e9;
    border-right: 2px solid #e8f5e9;
}

.login-content {
    max-width: 450px;
    width: 100%;
}

.login-header {
    text-align: center;
    margin-bottom: 32px;
}

.login-icon {
    font-size: 80px;
    margin-bottom: 16px;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.login-title {
    color: #2e7d32;
    margin: 0 0 8px 0;
    font-size: 28px;
    font-weight: 700;
}

.login-subtitle {
    color: #666;
    margin: 0;
    font-size: 15px;
    line-height: 1.5;
}

.login-form {
    background: #f8fdf9;
    padding: 32px;
    border-radius: 16px;
    border: 2px solid #e8f5e9;
    box-shadow: 0 4px 12px rgba(106, 168, 79, 0.08);
}

.form-group {
    margin-bottom: 20px;
}

.form-group:last-of-type {
    margin-bottom: 24px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    font-size: 14px;
}

.form-input {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 15px;
    transition: all 0.2s;
    font-family: inherit;
    box-sizing: border-box;
}

.form-input:focus {
    outline: none;
    border-color: #6aa84f;
    box-shadow: 0 0 0 3px rgba(106, 168, 79, 0.1);
}

.form-input::placeholder {
    color: #999;
}

.form-hint {
    font-size: 12px;
    color: #666;
    margin-top: 6px;
    display: flex;
    align-items: center;
    gap: 4px;
}

.login-button {
    width: 100%;
    padding: 16px 24px;
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    box-shadow: 0 4px 12px rgba(106, 168, 79, 0.3);
}

.login-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(106, 168, 79, 0.4);
}

.login-button:active {
    transform: translateY(0);
}

.security-note {
    text-align: center;
    margin-top: 20px;
    padding: 12px;
    background: rgba(106, 168, 79, 0.05);
    border-radius: 8px;
    font-size: 12px;
    color: #666;
}

.security-note::before {
    content: "🔒 ";
}

.error-message {
    background: #fee;
    color: #c33;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 12px;
    border-left: 4px solid #c33;
}

/* Rest of the existing styles... */
.message {
    display: flex;
    margin-bottom: 16px;
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.message-content {
    max-width: 70%;
    padding: 12px 16px;
    border-radius: 12px;
    position: relative;
    word-wrap: break-word;
}

.message.customer {
    justify-content: flex-end;
}

.message.customer .message-content {
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    border-bottom-right-radius: 4px;
}

.message.farmer {
    justify-content: flex-start;
}

.message.farmer .message-content {
    background: #f0f7ed;
    color: #1a1a1a;
    border-bottom-left-radius: 4px;
}

.message-sender {
    font-weight: 600;
    font-size: 12px;
    margin-bottom: 4px;
    opacity: 0.9;
}

.message-text {
    line-height: 1.5;
    font-size: 14px;
}

.message-time {
    font-size: 11px;
    opacity: 0.7;
    margin-top: 4px;
}

.message.customer .message-time {
    text-align: right;
}

.chat-input-container {
    background: white;
    padding: 20px 24px;
    border-radius: 0 0 12px 12px;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.05);
    border: 2px solid #e8f5e9;
    border-top: none;
}

.customer-info-bar {
    background: #f0f7ed;
    padding: 10px 16px;
    border-radius: 8px;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: #2e7d32;
}

.customer-info-text {
    font-weight: 600;
}

.change-phone-btn {
    background: none;
    border: none;
    color: #6aa84f;
    font-size: 12px;
    cursor: pointer;
    text-decoration: underline;
    padding: 0;
    font-weight: 600;
}

.change-phone-btn:hover {
    color: #5a923f;
}

.chat-input-form {
    display: flex;
    gap: 12px;
    align-items: flex-end;
}

.chat-textarea {
    flex: 1;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 14px;
    font-family: inherit;
    resize: none;
    min-height: 44px;
    max-height: 120px;
    transition: all 0.2s;
}

.chat-textarea:focus {
    outline: none;
    border-color: #6aa84f;
    box-shadow: 0 0 0 3px rgba(106, 168, 79, 0.1);
}

.send-button {
    padding: 12px 24px;
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 8px;
    white-space: nowrap;
}

.send-button:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(106, 168, 79, 0.3);
}

.send-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.empty-chat {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.empty-chat-icon {
    font-size: 64px;
    margin-bottom: 16px;
}

.empty-chat p {
    margin: 8px 0;
    font-size: 15px;
}

@media (max-width: 768px) {
    .chat-container {
        margin: 10px auto;
        padding: 0 10px;
        height: calc(100vh - 120px);
    }
    
    .chat-header {
        padding: 16px;
    }
    
    .farmer-avatar {
        width: 40px;
        height: 40px;
        font-size: 20px;
    }
    
    .farmer-details h3 {
        font-size: 18px;
    }
    
    .message-content {
        max-width: 85%;
    }
    
    .chat-input-form {
        flex-direction: column;
        gap: 8px;
    }
    
    .send-button {
        width: 100%;
        justify-content: center;
    }
    
    .login-screen {
        padding: 24px 16px;
    }
    
    .login-form {
        padding: 24px;
    }
    
    .login-icon {
        font-size: 64px;
    }
    
    .login-title {
        font-size: 24px;
    }
}

.chat-messages::-webkit-scrollbar {
    width: 8px;
}

.chat-messages::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.chat-messages::-webkit-scrollbar-thumb {
    background: #c8e6c9;
    border-radius: 4px;
}

.chat-messages::-webkit-scrollbar-thumb:hover {
    background: #a5d6a7;
}
</style>

<div class="chat-container">
    <div class="chat-header">
        <div class="chat-header-content">
            <div class="farmer-info">
                <div class="farmer-avatar">🌾</div>
                <div class="farmer-details">
                    <h3><?= h($farmer['name']) ?></h3>
                    <p><?= h($farmer['farm_name']) ?></p>
                </div>
            </div>
            <div class="header-actions">
                <a href="tel:<?= h($farmer['phone']) ?>" class="action-button">
                    <span>📞</span>
                    <span>Call</span>
                </a>
                <a href="<?= $product_id ? 'product_details.php?id=' . h($product_id) : 'customersdashboard.php' ?>" class="action-button">
                    <span>🔙</span>
                    <span>Back</span>
                </a>
            </div>
        </div>
        
        <?php if ($product): ?>
            <div class="product-context">
                <span>📦</span>
                <span><strong>About:</strong> <?= h($product['name']) ?> - ₱<?= number_format($product['price'], 2) ?>/kg</span>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if ($needs_phone): ?>
        <!-- Customer Login Screen -->
        <div class="login-screen">
            <div class="login-content">
                <div class="login-header">
                    <div class="login-icon">👤</div>
                    <h2 class="login-title">Customer Login</h2>
                    <p class="login-subtitle">
                        Please enter your details to start chatting with <?= h($farmer['name']) ?>
                    </p>
                </div>
                
                <form method="POST" action="chat.php?farmer_id=<?= h($farmer_id) ?><?= $product_id ? '&product_id=' . h($product_id) : '' ?>" class="login-form">
                    <div class="form-group">
                        <label class="form-label" for="customer_name">
                            📝 Username
                        </label>
                        <input 
                            type="text" 
                            id="customer_name"
                            name="customer_name" 
                            class="form-input" 
                            placeholder="Enter your username"
                            required
                            autocomplete="name"
                        >
                    </div>
                    
                    <div class="form-group">
    <label class="form-label" for="customer_phone">
        📱 Phone Number
    </label>
    <input 
        type="tel" 
        id="customer_phone"
        name="customer_phone" 
        class="form-input" 
        placeholder="09171234567"
        required
        pattern="09[0-9]{9}"
        title="Phone number must start with 09 and be 11 digits long"
        autocomplete="tel"
    >
    <div class="form-hint">
        ℹ️ Enter your 11-digit Philippine mobile number (must start with 09)
    </div>
</div>

                    <button type="submit" name="start_chat" class="login-button">
                        <span>💬</span>
                        <span>Start Chatting</span>
                    </button>
                    
                    <div class="security-note">
                        Your information is secure and will only be used for communication
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- Chat Messages -->
        <div class="chat-messages" id="chatMessages">
            <?php if (isset($error_message)): ?>
                <div class="error-message"><?= h($error_message) ?></div>
            <?php endif; ?>
            
            <?php if (empty($messages)): ?>
                <div class="empty-chat">
                    <div class="empty-chat-icon">💬</div>
                    <p><strong>Start the conversation</strong></p>
                    <p>Send a message to <?= h($farmer['name']) ?> about their products</p>
                </div>
            <?php else: ?>
                <?php foreach ($messages as $msg): ?>
                    <div class="message <?= h($msg['sender_type']) ?>">
                        <div class="message-content">
                            <?php if ($msg['sender_type'] === 'farmer'): ?>
                                <div class="message-sender"><?= h($msg['farmer_name']) ?></div>
                            <?php endif; ?>
                            <div class="message-text"><?= nl2br(h($msg['message'])) ?></div>
                            <div class="message-time">
                                <?= date('M j, g:i A', strtotime($msg['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Chat Input -->
        <div class="chat-input-container">
            <div class="customer-info-bar">
                <span class="customer-info-text">
                    💬 Chatting as: <?= h($customer_name) ?> (<?= h($customer_phone) ?>)
                </span>
                <form method="POST" action="chat.php?farmer_id=<?= h($farmer_id) ?><?= $product_id ? '&product_id=' . h($product_id) : '' ?>" style="display: inline;">
                    <button type="submit" name="change_phone" class="change-phone-btn">
                        Change
                    </button>
                </form>
            </div>
            
            <form method="POST" action="chat.php?farmer_id=<?= h($farmer_id) ?><?= $product_id ? '&product_id=' . h($product_id) : '' ?>" class="chat-input-form" id="chatForm">
                <textarea 
                    name="message" 
                    class="chat-textarea" 
                    placeholder="Type your message here..."
                    required
                    rows="1"
                    id="messageInput"
                ></textarea>
                <button type="submit" class="send-button" id="sendButton">
                    <span>📤</span>
                    <span>Send</span>
                </button>
            </form>
        </div>
    <?php endif; ?>
</div>

<script>
<?php if (!$needs_phone): ?>
// Auto-resize textarea
const textarea = document.getElementById('messageInput');
if (textarea) {
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
}

// Auto-scroll to bottom on page load
const chatMessages = document.getElementById('chatMessages');
if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Handle form submission
const chatForm = document.getElementById('chatForm');
const sendButton = document.getElementById('sendButton');

if (chatForm) {
    chatForm.addEventListener('submit', function(e) {
        if (sendButton.disabled) {
            e.preventDefault();
            return false;
        }
        sendButton.disabled = true;
        sendButton.innerHTML = '<span>⏳</span><span>Sending...</span>';
    });
}

// Allow Enter to send, Shift+Enter for new line
if (textarea) {
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (this.value.trim()) {
                chatForm.submit();
            }
        }
    });
}

// Auto-refresh messages every 5 seconds
setInterval(function() {
    if (document.activeElement !== textarea) {
        const scrollAtBottom = Math.abs(chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight) < 50;
        
        fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newMessages = doc.getElementById('chatMessages');
                
                if (newMessages && newMessages.innerHTML !== chatMessages.innerHTML) {
                    chatMessages.innerHTML = newMessages.innerHTML;
                    
                    if (scrollAtBottom) {
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    }
                }
            })
            .catch(err => console.error('Error refreshing messages:', err));
    }
}, 5000);
<?php endif; ?>
</script>

<?php require 'footer.php'; ?>