<?php
require 'config.php';
require 'header.php';

// Auto-delete sold products older than 30 minutes
$pdo->exec("DELETE FROM products WHERE status='sold' AND sold_at IS NOT NULL AND sold_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)");

$q = trim($_GET['q'] ?? '');
$params = [];
$sql = "SELECT p.*, f.name AS farmer_name, f.farm_name, f.phone as farmer_phone FROM products p JOIN farmers f ON p.farmer_id=f.id WHERE p.status='available'";
if($q){ $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)"; $params[] = "%$q%"; $params[] = "%$q%"; }
$sql .= " ORDER BY p.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$list = $stmt->fetchAll();
?>

<style>
/* Enhanced Marketplace Background */
body {
    margin: 0;
    min-height: 100vh;
    position: relative;
    background: linear-gradient(135deg, #e8f5e9 0%, #f1f8f4 30%, #fff8e1 70%, #fef3e2 100%);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: 
        radial-gradient(circle at 20% 50%, rgba(76, 175, 80, 0.05) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(255, 193, 7, 0.05) 0%, transparent 50%),
        repeating-linear-gradient(90deg, rgba(76, 175, 80, 0.02) 0px, transparent 1px, transparent 60px, rgba(76, 175, 80, 0.02) 61px),
        repeating-linear-gradient(0deg, rgba(76, 175, 80, 0.02) 0px, transparent 1px, transparent 60px, rgba(76, 175, 80, 0.02) 61px);
    z-index: -2;
}

body::after {
    content: '🌾 🥕 🥬 🍅 🌽 🥦 🥒 🧅 🥔 🍆 🫑 🥗 🌱';
    position: fixed;
    top: 40px;
    left: 0;
    width: 200%;
    text-align: center;
    font-size: 42px;
    opacity: 0.06;
    letter-spacing: 60px;
    z-index: -1;
    animation: slideVeggies 40s linear infinite;
}

@keyframes slideVeggies {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

/* Floating elements */
.floating-element {
    position: fixed;
    font-size: 35px;
    opacity: 0.12;
    animation: float 20s ease-in-out infinite;
    z-index: -1;
}

.floating-element:nth-child(1) { top: 15%; left: 8%; animation-delay: 0s; }
.floating-element:nth-child(2) { top: 25%; right: 12%; animation-delay: 4s; }
.floating-element:nth-child(3) { top: 65%; left: 10%; animation-delay: 8s; }
.floating-element:nth-child(4) { top: 75%; right: 8%; animation-delay: 12s; }

@keyframes float {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    25% { transform: translateY(-25px) rotate(8deg); }
    50% { transform: translateY(-15px) rotate(-8deg); }
    75% { transform: translateY(-35px) rotate(5deg); }
}

.browse-container {
    max-width: 1300px;
    margin: 40px auto 100px;
    padding: 0 20px;
    position: relative;
    z-index: 1;
}

/* Enhanced Browse Header */
.browse-header {
    background: linear-gradient(135deg, #66bb6a 0%, #4caf50 50%, #388e3c 100%);
    color: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(76, 175, 80, 0.3);
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}

.browse-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.15) 0%, transparent 70%);
    border-radius: 50%;
    animation: pulse-glow 5s ease-in-out infinite;
}

.browse-header::after {
    content: '';
    position: absolute;
    bottom: -50%;
    left: -5%;
    width: 280px;
    height: 280px;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
    border-radius: 50%;
    animation: pulse-glow 6s ease-in-out infinite;
    animation-delay: 1.5s;
}

@keyframes pulse-glow {
    0%, 100% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.3); opacity: 0.9; }
}

.browse-header > * {
    position: relative;
    z-index: 1;
}

.browse-header h3 {
    margin: 0 0 12px 0;
    font-size: 32px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.browse-header h3 span {
    font-size: 38px;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
}

.browse-header p {
    margin: 0;
    opacity: 0.95;
    font-size: 16px;
    font-weight: 500;
}

/* Enhanced Search Section */
.search-section {
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(20px);
    padding: 32px;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 28px;
    border: 1px solid rgba(224, 224, 224, 0.5);
}

.search-form {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
}

.search-input {
    flex: 1;
    padding: 16px 20px;
    border: 2px solid #e8f5e9;
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s ease;
    background: white;
    font-family: inherit;
}

.search-input:focus {
    outline: none;
    border-color: #66bb6a;
    box-shadow: 0 0 0 4px rgba(102, 187, 106, 0.1);
    transform: translateY(-2px);
}

.search-button {
    padding: 16px 40px;
    background: linear-gradient(135deg, #66bb6a 0%, #4caf50 100%);
    color: white;
    border: none;
    border-radius: 12px;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.search-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(76, 175, 80, 0.4);
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%);
}

.search-button:active {
    transform: translateY(-1px);
}

.info-banner {
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
    color: #2e7d32;
    padding: 16px 20px;
    border-radius: 10px;
    font-size: 15px;
    border-left: 5px solid #66bb6a;
    line-height: 1.6;
    box-shadow: 0 2px 8px rgba(76, 175, 80, 0.1);
}

.info-banner strong {
    font-weight: 700;
}

.results-count {
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(20px);
    padding: 18px 28px;
    border-radius: 12px;
    margin-bottom: 24px;
    color: #555;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 2px solid #e8f5e9;
    font-size: 15px;
}

/* Enhanced Products Grid */
.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
    gap: 24px;
}

.product-card {
    background: linear-gradient(135deg, #ffffff 0%, #fafafa 100%);
    border: 2px solid #e8f5e9;
    border-radius: 16px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 4px 12px rgba(76, 175, 80, 0.08);
    display: flex;
    flex-direction: column;
    position: relative;
}

.product-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: linear-gradient(90deg, #66bb6a 0%, #4caf50 50%, #2e7d32 100%);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.product-card:hover {
    box-shadow: 0 12px 32px rgba(76, 175, 80, 0.2);
    transform: translateY(-8px);
    border-color: #c8e6c9;
}

.product-card:hover::before {
    transform: scaleX(1);
}

.product-image-wrapper {
    width: 100%;
    height: 240px;
    background: #f5f5f5;
    position: relative;
    overflow: hidden;
}

.product-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.product-card:hover .product-image {
    transform: scale(1.1) rotate(2deg);
}

.no-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 80px;
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
    animation: float 4s ease-in-out infinite;
}

.product-content {
    padding: 24px;
    display: flex;
    flex-direction: column;
    flex: 1;
}

.product-name {
    font-size: 20px;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 12px;
    line-height: 1.3;
    transition: color 0.3s ease;
}

.product-card:hover .product-name {
    color: #2e7d32;
}

.farmer-badge {
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
    color: #2e7d32;
    padding: 8px 14px;
    border-radius: 20px;
    font-size: 13px;
    margin-bottom: 14px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    border: 2px solid #c8e6c9;
    align-self: flex-start;
    transition: all 0.3s ease;
    box-shadow: 0 2px 6px rgba(76, 175, 80, 0.1);
}

.product-card:hover .farmer-badge {
    background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
    transform: translateX(5px);
}

.product-description {
    color: #666;
    line-height: 1.6;
    margin-bottom: 16px;
    font-size: 14px;
    flex: 1;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.product-meta {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 20px;
    padding-top: 16px;
    border-top: 2px dashed #e8f5e9;
}

.meta-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
    background: #f8fef9;
    padding: 12px;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.product-card:hover .meta-item {
    background: #f0f7ed;
    transform: translateY(-2px);
}

.meta-label {
    font-size: 11px;
    color: #888;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.meta-value {
    font-size: 18px;
    font-weight: 800;
    background: linear-gradient(135deg, #2e7d32 0%, #66bb6a 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.contact-buttons {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.contact-button {
    background: linear-gradient(135deg, #66bb6a 0%, #4caf50 100%);
    color: white;
    padding: 14px 12px;
    border-radius: 10px;
    text-align: center;
    font-weight: 700;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    text-decoration: none;
    box-shadow: 0 2px 8px rgba(76, 175, 80, 0.2);
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.contact-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(76, 175, 80, 0.35);
}

.contact-button.chat-button {
    background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
    box-shadow: 0 2px 8px rgba(33, 150, 243, 0.2);
}

.contact-button.chat-button:hover {
    box-shadow: 0 6px 16px rgba(33, 150, 243, 0.35);
}

/* Enhanced Empty State */
.empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 100px 40px;
    background: linear-gradient(135deg, #ffffff 0%, #f8fef9 100%);
    backdrop-filter: blur(20px);
    border-radius: 20px;
    border: 3px dashed #c8e6c9;
    box-shadow: 0 4px 20px rgba(76, 175, 80, 0.08);
}

.empty-state-icon {
    font-size: 80px;
    margin-bottom: 20px;
    animation: float 3s ease-in-out infinite;
}

.empty-state p {
    color: #999;
    font-size: 18px;
    margin: 0;
    font-weight: 600;
}

.empty-state p:last-child {
    margin-top: 12px;
    font-size: 15px;
    font-weight: 500;
    color: #bbb;
}

@media (max-width: 768px) {
    .browse-header h3 {
        font-size: 26px;
    }
    
    .products-grid {
        grid-template-columns: 1fr;
    }
    
    .search-form {
        flex-direction: column;
    }
    
    .search-button {
        width: 100%;
        padding: 14px;
    }
    
    .product-meta {
        grid-template-columns: 1fr;
    }
    
    .contact-buttons {
        grid-template-columns: 1fr;
    }
    
    .product-image-wrapper {
        height: 220px;
    }
}

@media (min-width: 769px) and (max-width: 1024px) {
    .products-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (min-width: 1400px) {
    .products-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}
</style>

<div class="floating-element">🍅</div>
<div class="floating-element">🥕</div>
<div class="floating-element">🌽</div>
<div class="floating-element">🥦</div>

<div class="browse-container">
    <div class="browse-header">
        <h3><span>🛒</span> Browse Fresh Products</h3>
        <p>Discover fresh vegetables and produce directly from local farmers</p>
    </div>
    
    <div class="search-section">
        <form method="get" class="search-form">
            <input name="q" class="search-input" placeholder="🔍 Search for vegetables, fruits, or any product..." value="<?=h($q)?>">
            <button type="submit" class="search-button">Search</button>
        </form>
        <div class="info-banner">
            <strong>💡 How to buy:</strong> No login needed! Simply click the chat button to message the farmer directly, or call them to arrange your purchase.
        </div>
    </div>
    
    <?php if($list): ?>
        <div class="results-count">
            📦 Found <?=count($list)?> product<?=count($list) !== 1 ? 's' : ''?> <?=$q ? 'for "'.h($q).'"' : ''?>
        </div>
    <?php endif; ?>
    
    <div class="products-grid">
        <?php if(!$list): ?>
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <p><?=$q ? 'No products found matching your search.' : 'No products available at the moment.'?></p>
                <p>Try searching for something else or check back later!</p>
            </div>
        <?php endif; ?>
        
        <?php foreach($list as $p): ?>
            <div class="product-card">
                <a href="product_details.php?id=<?=h($p['id'])?>" style="text-decoration: none; color: inherit;">
                    <div class="product-image-wrapper">
                        <?php if($p['image'] && file_exists($p['image'])): ?>
                            <img src="<?=h($p['image'])?>" alt="<?=h($p['name'])?>" class="product-image">
                        <?php else: ?>
                            <div class="no-image-placeholder">🥬</div>
                        <?php endif; ?>
                    </div>
                </a>
                
                <div class="product-content">
                    <a href="product_details.php?id=<?=h($p['id'])?>" style="text-decoration: none; color: inherit;">
                        <div class="product-name"><?=h($p['name'])?></div>
                    </a>
                    
                    <div class="farmer-badge">
                        <span>🌾</span>
                        <span><?=h($p['farmer_name'])?></span>
                    </div>
                    
                    <?php if($p['description']): ?>
                        <div class="product-description"><?=h($p['description'])?></div>
                    <?php endif; ?>
                    
                    <div class="product-meta">
                        <div class="meta-item">
                            <span class="meta-label">💰 Price/kg</span>
                            <span class="meta-value">₱<?=number_format($p['price'],2)?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">📦 Available</span>
                            <span class="meta-value"><?=number_format($p['quantity'],1)?> kg</span>
                        </div>
                    </div>
                    
                    <div class="contact-buttons">
                        <a href="tel:<?=h($p['farmer_phone'])?>" class="contact-button">
                            <span>📞</span>
                            <span>Call</span>
                        </a>
                        <a href="chat.php?farmer_id=<?=h($p['farmer_id'])?>&product_id=<?=h($p['id'])?>" class="contact-button chat-button">
                            <span>💬</span>
                            <span>Chat</span>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require 'footer.php'; ?>