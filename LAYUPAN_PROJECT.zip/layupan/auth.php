<?php
// auth.php - Authentication helper (no output)
if(!function_exists('require_login')) {
    function require_login() {
        if(!isset($_SESSION['farmer_id'])) {
            header('Location: farmerlogin.php');
            exit;
        }
    }
}

if(!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}
?>