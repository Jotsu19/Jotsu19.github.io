<?php
require 'config.php';

// Get product ID from URL
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if(!$product_id){
    header('Location: customersdashboard.php');
    exit;
}

// Fetch product details with farmer information
$stmt = $pdo->prepare("
    SELECT p.*, 
           f.name AS farmer_name, 
           f.farm_name, 
           f.phone AS farmer_phone,
           f.id AS farmer_id
    FROM products p 
    JOIN farmers f ON p.farmer_id = f.id 
    WHERE p.id = ? AND p.status = 'available'
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if(!$product){
    header('Location: customersdashboard.php');
    exit;
}

// Get other products from the same farmer
$stmt = $pdo->prepare("
    SELECT * FROM products 
    WHERE farmer_id = ? AND id != ? AND status = 'available' 
    ORDER BY id DESC 
    LIMIT 3
");
$stmt->execute([$product['farmer_id'], $product_id]);
$other_products = $stmt->fetchAll();

// Helper function for HTML escaping
if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// Now include header after all redirects are done
require 'header.php';
?>

<style>
/* Marketplace Background */
body {
    margin: 0;
    min-height: 100vh;
    position: relative;
    background: linear-gradient(to bottom, #e8f5e9 0%, #f1f8f4 50%, #fff8e1 100%);
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: 
        repeating-linear-gradient(90deg, rgba(76, 175, 80, 0.03) 0px, transparent 1px, transparent 50px, rgba(76, 175, 80, 0.03) 51px),
        repeating-linear-gradient(0deg, rgba(76, 175, 80, 0.03) 0px, transparent 1px, transparent 50px, rgba(76, 175, 80, 0.03) 51px);
    z-index: -2;
}

body::after {
    content: '🌾 🥕 🥬 🍅 🌽 🥦 🥒 🧅 🥔 🍆';
    position: fixed;
    top: 20px;
    left: 0;
    width: 100%;
    text-align: center;
    font-size: 40px;
    opacity: 0.08;
    letter-spacing: 40px;
    z-index: -1;
    animation: slideVeggies 30s linear infinite;
}

@keyframes slideVeggies {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

.market-decoration {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 80px;
    background: linear-gradient(to top, rgba(139, 69, 19, 0.1) 0%, transparent 100%);
    z-index: -1;
}

.market-decoration::before {
    content: '🏪';
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 50px;
    opacity: 0.15;
}

.product-detail-container {
    max-width: 1100px;
    margin: 40px auto 100px;
    padding: 0 20px;
    position: relative;
    z-index: 1;
}

.back-nav {
    margin-bottom: 20px;
}

.back-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 12px 20px;
    border-radius: 8px;
    color: #333;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.2s;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.back-button:hover {
    background: white;
    transform: translateX(-4px);
}

.product-detail-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    border: 2px solid #e8f5e9;
}

.product-detail-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
    padding: 40px;
}

.product-image-section {
    position: relative;
}

.main-product-image {
    width: 100%;
    height: 500px;
    object-fit: cover;
    border-radius: 12px;
    border: 2px solid #e8f5e9;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.no-image-placeholder-large {
    width: 100%;
    height: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 120px;
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
    border-radius: 12px;
    border: 2px solid #e8f5e9;
}

.product-info-section {
    display: flex;
    flex-direction: column;
}

.product-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #d1fae5;
    color: #065f46;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    width: fit-content;
    margin-bottom: 16px;
}

.product-title {
    font-size: 36px;
    font-weight: 700;
    color: #1a1a1a;
    margin: 0 0 16px 0;
    line-height: 1.2;
}

.farmer-info-box {
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
    padding: 16px 20px;
    border-radius: 10px;
    border: 2px solid #c8e6c9;
    margin-bottom: 24px;
}

.farmer-info-box h4 {
    margin: 0 0 8px 0;
    font-size: 14px;
    color: #2e7d32;
    font-weight: 600;
    text-transform: uppercase;
}

.farmer-name {
    font-size: 18px;
    font-weight: 600;
    color: #1a1a1a;
    margin-bottom: 4px;
}

.farm-name {
    font-size: 14px;
    color: #666;
    display: flex;
    align-items: center;
    gap: 6px;
}

.product-description-section {
    margin-bottom: 24px;
}

.product-description-section h4 {
    font-size: 16px;
    font-weight: 600;
    color: #333;
    margin: 0 0 12px 0;
}

.product-description-text {
    color: #666;
    line-height: 1.6;
    font-size: 15px;
}

.product-pricing {
    background: #f8f9fa;
    padding: 24px;
    border-radius: 10px;
    margin-bottom: 24px;
}

.price-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.price-row:last-child {
    margin-bottom: 0;
    padding-top: 16px;
    border-top: 2px dashed #e0e0e0;
}

.price-label {
    font-size: 14px;
    color: #666;
    font-weight: 600;
}

.price-value {
    font-size: 28px;
    font-weight: 700;
    color: #2e7d32;
}

.quantity-value {
    font-size: 20px;
    font-weight: 600;
    color: #333;
}

.contact-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.contact-btn {
    padding: 16px;
    border-radius: 10px;
    text-align: center;
    font-weight: 600;
    font-size: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
    border: none;
    cursor: pointer;
    text-decoration: none;
}

.contact-btn-call {
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(106, 168, 79, 0.3);
}

.contact-btn-call:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(106, 168, 79, 0.4);
}

.contact-btn-chat {
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

.contact-btn-chat:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(74, 144, 226, 0.4);
}

.other-products-section {
    margin-top: 60px;
}

.section-title {
    font-size: 24px;
    font-weight: 600;
    color: #1a1a1a;
    margin: 0 0 24px 0;
    padding-bottom: 12px;
    border-bottom: 2px solid #e8f5e9;
}

.other-products-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.mini-product-card {
    background: white;
    border: 2px solid #e8f5e9;
    border-radius: 12px;
    overflow: hidden;
    transition: all 0.3s;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    text-decoration: none;
    color: inherit;
}

.mini-product-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 6px 20px rgba(106, 168, 79, 0.15);
    border-color: #c8e6c9;
}

.mini-product-image {
    width: 100%;
    height: 150px;
    object-fit: cover;
}

.mini-no-image {
    width: 100%;
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    background: linear-gradient(135deg, #f0f7ed 0%, #e8f5e9 100%);
}

.mini-product-info {
    padding: 16px;
}

.mini-product-name {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a1a;
    margin-bottom: 8px;
}

.mini-product-price {
    font-size: 18px;
    font-weight: 700;
    color: #2e7d32;
}

@media (max-width: 768px) {
    .product-detail-content {
        grid-template-columns: 1fr;
        gap: 30px;
        padding: 24px;
    }
    
    .main-product-image,
    .no-image-placeholder-large {
        height: 300px;
    }
    
    .product-title {
        font-size: 28px;
    }
    
    .contact-section {
        grid-template-columns: 1fr;
    }
    
    .other-products-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="market-decoration"></div>

<div class="product-detail-container">
    <div class="back-nav">
        <a href="customersdashboard.php" class="back-button">
            <span>←</span>
            <span>Back to Products</span>
        </a>
    </div>
    
    <div class="product-detail-card">
        <div class="product-detail-content">
            <!-- Left: Product Image -->
            <div class="product-image-section">
                <?php if($product['image'] && file_exists($product['image'])): ?>
                    <img src="<?=h($product['image'])?>" alt="<?=h($product['name'])?>" class="main-product-image">
                <?php else: ?>
                    <div class="no-image-placeholder-large">🥬</div>
                <?php endif; ?>
            </div>
            
            <!-- Right: Product Info -->
            <div class="product-info-section">
                <div class="product-status-badge">
                    <span>🟢</span>
                    <span>Available</span>
                </div>
                
                <h1 class="product-title"><?=h($product['name'])?></h1>
                
                <!-- Farmer Information -->
                <div class="farmer-info-box">
                    <h4>🌾 Sold By</h4>
                    <div class="farmer-name"><?=h($product['farmer_name'])?></div>
                    <div class="farm-name">
                        <span>🏡</span>
                        <span><?=h($product['farm_name'] ?: 'Local Farm')?></span>
                    </div>
                </div>
                
                <!-- Description -->
                <?php if($product['description']): ?>
                <div class="product-description-section">
                    <h4>📝 Description</h4>
                    <div class="product-description-text">
                        <?=nl2br(h($product['description']))?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Pricing & Quantity -->
                <div class="product-pricing">
                    <div class="price-row">
                        <span class="price-label">💰 Price per Kilogram</span>
                        <span class="price-value">₱<?=number_format($product['price'],2)?></span>
                    </div>
                    <div class="price-row">
                        <span class="price-label">📦 Available Quantity</span>
                        <span class="quantity-value"><?=number_format($product['quantity'],1)?> kg</span>
                    </div>
                </div>
                
                <!-- Contact Buttons -->
                <div class="contact-section">
                    <a href="tel:<?=h($product['farmer_phone'])?>" class="contact-btn contact-btn-call">
                        <span>📞</span>
                        <span>Call Now</span>
                    </a>
                    <a href="chat.php?farmer_id=<?=h($product['farmer_id'])?>&product_id=<?=h($product['id'])?>" class="contact-btn contact-btn-chat">
                        <span>💬</span>
                        <span>Chat with Farmer</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Other Products from Same Farmer -->
    <?php if($other_products): ?>
    <div class="other-products-section">
        <h3 class="section-title">More from <?=h($product['farmer_name'])?></h3>
        <div class="other-products-grid">
            <?php foreach($other_products as $op): ?>
                <a href="product_details.php?id=<?=h($op['id'])?>" class="mini-product-card">
                    <?php if($op['image'] && file_exists($op['image'])): ?>
                        <img src="<?=h($op['image'])?>" alt="<?=h($op['name'])?>" class="mini-product-image">
                    <?php else: ?>
                        <div class="mini-no-image">🥬</div>
                    <?php endif; ?>
                    <div class="mini-product-info">
                        <div class="mini-product-name"><?=h($op['name'])?></div>
                        <div class="mini-product-price">₱<?=number_format($op['price'],2)?>/kg</div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require 'footer.php'; ?>