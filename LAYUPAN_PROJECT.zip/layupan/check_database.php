<?php
require 'config.php';

echo "<h1>Database Diagnostic Tool</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    h1 { color: #2e7d32; }
    h2 { color: #4a90e2; margin-top: 30px; }
    .success { color: green; font-weight: bold; }
    .error { color: red; font-weight: bold; }
    .warning { color: orange; font-weight: bold; }
    table { border-collapse: collapse; width: 100%; margin: 10px 0; background: white; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background: #4a90e2; color: white; }
    tr:nth-child(even) { background: #f9f9f9; }
    .code { background: #f4f4f4; padding: 10px; border-radius: 5px; margin: 10px 0; overflow-x: auto; }
</style>";

// Check if database connection works
try {
    $pdo->query("SELECT 1");
    echo "<p class='success'>✅ Database connection successful!</p>";
} catch (PDOException $e) {
    echo "<p class='error'>❌ Database connection failed: " . $e->getMessage() . "</p>";
    exit;
}

echo "<h2>📋 All Tables in Database</h2>";
try {
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($tables)) {
        echo "<p class='warning'>⚠️ No tables found in database!</p>";
    } else {
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li><strong>$table</strong></li>";
        }
        echo "</ul>";
    }
} catch (PDOException $e) {
    echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
}

// Check each required table
$requiredTables = ['farmers', 'products', 'messages'];

foreach ($requiredTables as $tableName) {
    echo "<h2>🔍 Checking table: <code>$tableName</code></h2>";
    
    try {
        // Check if table exists
        $stmt = $pdo->query("SHOW TABLES LIKE '$tableName'");
        if ($stmt->rowCount() == 0) {
            echo "<p class='error'>❌ Table '$tableName' does NOT exist!</p>";
            echo "<p>You need to create this table. Check the 'Complete Database Setup' artifact.</p>";
            continue;
        }
        
        echo "<p class='success'>✅ Table exists</p>";
        
        // Show table structure
        $stmt = $pdo->query("DESCRIBE $tableName");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table>";
        echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td><strong>" . htmlspecialchars($col['Field']) . "</strong></td>";
            echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Null']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Key']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Default'] ?? 'NULL') . "</td>";
            echo "<td>" . htmlspecialchars($col['Extra']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Count records
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $tableName");
        $count = $stmt->fetch()['count'];
        echo "<p>📊 Total records: <strong>$count</strong></p>";
        
        // Check for specific required columns
        $columnNames = array_column($columns, 'Field');
        
        if ($tableName === 'messages') {
            $requiredColumns = ['customer_phone', 'customer_name', 'farmer_id', 'sender_type', 'message'];
            echo "<h3>Required Columns Check:</h3>";
            foreach ($requiredColumns as $reqCol) {
                if (in_array($reqCol, $columnNames)) {
                    echo "<p class='success'>✅ Column '$reqCol' exists</p>";
                } else {
                    echo "<p class='error'>❌ Missing column '$reqCol'</p>";
                }
            }
        }
        
        if ($tableName === 'farmers') {
            $requiredColumns = ['id', 'name', 'email', 'phone'];
            echo "<h3>Required Columns Check:</h3>";
            foreach ($requiredColumns as $reqCol) {
                if (in_array($reqCol, $columnNames)) {
                    echo "<p class='success'>✅ Column '$reqCol' exists</p>";
                } else {
                    echo "<p class='error'>❌ Missing column '$reqCol'</p>";
                }
            }
        }
        
        if ($tableName === 'products') {
            $requiredColumns = ['id', 'farmer_id', 'name', 'price', 'quantity'];
            echo "<h3>Required Columns Check:</h3>";
            foreach ($requiredColumns as $reqCol) {
                if (in_array($reqCol, $columnNames)) {
                    echo "<p class='success'>✅ Column '$reqCol' exists</p>";
                } else {
                    echo "<p class='error'>❌ Missing column '$reqCol'</p>";
                }
            }
        }
        
    } catch (PDOException $e) {
        echo "<p class='error'>❌ Error checking table: " . $e->getMessage() . "</p>";
    }
}

echo "<h2>🎯 Summary</h2>";
$allGood = true;

// Check all required tables exist
foreach ($requiredTables as $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() == 0) {
            echo "<p class='error'>❌ Missing table: $table</p>";
            $allGood = false;
        }
    } catch (PDOException $e) {
        $allGood = false;
    }
}

if ($allGood) {
    echo "<p class='success' style='font-size: 20px;'>✅ All required tables exist! Your database is ready.</p>";
} else {
    echo "<p class='error' style='font-size: 20px;'>❌ Some tables are missing. Please run the SQL from 'Complete Database Setup' artifact.</p>";
    echo "<div class='code'>";
    echo "<h3>Quick Fix SQL:</h3>";
    echo "<p>Copy and run this in your database (phpMyAdmin, MySQL Workbench, etc.):</p>";
    echo "<pre style='background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 5px; overflow-x: auto;'>";
    echo "-- Run the complete SQL from the 'Complete Database Setup' artifact";
    echo "</pre>";
    echo "</div>";
}

echo "<hr>";
echo "<p style='color: #666; font-size: 12px;'>Generated on " . date('Y-m-d H:i:s') . "</p>";
?>