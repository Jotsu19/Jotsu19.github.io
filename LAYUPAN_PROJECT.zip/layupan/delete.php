<?php
ob_start();
require 'config.php';
require 'auth.php';

require_login();

$farmer_id = $_SESSION['farmer_id'];
$product_id = $_GET['id'] ?? 0;

if($product_id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE id=? AND farmer_id=?");
        $stmt->execute([$product_id, $farmer_id]);
        
        header('Location: farmerdashboard.php?deleted=1');
        ob_end_flush();
        exit;
    } catch(PDOException $e) {
        header('Location: farmerdashboard.php?error=delete_failed');
        ob_end_flush();
        exit;
    }
} else {
    header('Location: farmerdashboard.php');
    ob_end_flush();
    exit;
}
?>