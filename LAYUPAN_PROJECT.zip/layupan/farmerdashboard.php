<?php
ob_start(); // Start output buffering
require 'config.php';

// Helper function
if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}

// Check authentication FIRST
if(!isset($_SESSION['farmer_id'])){ 
    header('Location: farmerlogin.php'); 
    ob_end_flush();
    exit; 
}

// Handle ALL POST requests BEFORE any HTML output
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(isset($_POST['add_product'])){
        $name = trim($_POST['product_name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $qty = floatval($_POST['quantity'] ?? 0);
        $phone = trim($_POST['contact_phone'] ?? '');
        $imagePath = null;
        
        if(isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK){
            $tmp = $_FILES['image']['tmp_name'];
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $fn = 'uploads/' . uniqid() . '.' . $ext;
            if(!is_dir('uploads')) mkdir('uploads', 0755, true);
            if(move_uploaded_file($tmp, $fn)){
                $imagePath = $fn;
            }
        }
        $stmt = $pdo->prepare("INSERT INTO products (farmer_id,name,description,price,quantity,image,contact_phone,status) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$_SESSION['farmer_id'],$name,$desc,$price,$qty,$imagePath,$phone,'available']);
        header('Location: farmerdashboard.php'); 
        ob_end_flush();
        exit;
    }
    if(isset($_POST['delete_product'])){
        $pid = intval($_POST['product_id']);
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id=? AND farmer_id=?"); 
        $stmt->execute([$pid, $_SESSION['farmer_id']]); 
        $img = $stmt->fetchColumn(); 
        if($img && file_exists($img)) @unlink($img);
        $stmt = $pdo->prepare("DELETE FROM products WHERE id=? AND farmer_id=?"); 
        $stmt->execute([$pid, $_SESSION['farmer_id']]); 
        header('Location: farmerdashboard.php'); 
        ob_end_flush();
        exit;
    }
    if(isset($_POST['mark_sold'])){
        $pid = intval($_POST['product_id']);
        $stmt = $pdo->prepare("UPDATE products SET status='sold', sold_at=NOW() WHERE id=? AND farmer_id=?");
        $stmt->execute([$pid, $_SESSION['farmer_id']]);
        header('Location: farmerdashboard.php'); 
        ob_end_flush();
        exit;
    }
    if(isset($_POST['mark_available'])){
        $pid = intval($_POST['product_id']);
        $stmt = $pdo->prepare("UPDATE products SET status='available' WHERE id=? AND farmer_id=?");
        $stmt->execute([$pid, $_SESSION['farmer_id']]);
        header('Location: farmerdashboard.php'); 
        ob_end_flush();
        exit;
    }
}

// Fetch farmer data
$stmt = $pdo->prepare("SELECT * FROM farmers WHERE id=?");
$stmt->execute([$_SESSION['farmer_id']]);
$farmer = $stmt->fetch();

// Get unread message count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as unread_count
    FROM messages
    WHERE farmer_id = ? AND sender_type = 'customer' AND is_read = 0
");
$stmt->execute([$_SESSION['farmer_id']]);
$unread_count = $stmt->fetch()['unread_count'];

// NOW we can include header.php
require 'header.php';
?>

<style>
/* Enhanced Marketplace Background */
body {
    margin: 0;
    min-height: 100vh;
    position: relative;
    background: linear-gradient(135deg, #e8f5e9 0%, #f1f8f4 30%, #fff8e1 70%, #fef3e2 100%);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: 
        radial-gradient(circle at 20% 50%, rgba(76, 175, 80, 0.05) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(255, 193, 7, 0.05) 0%, transparent 50%),
        repeating-linear-gradient(90deg, rgba(76, 175, 80, 0.02) 0px, transparent 1px, transparent 60px, rgba(76, 175, 80, 0.02) 61px),
        repeating-linear-gradient(0deg, rgba(76, 175, 80, 0.02) 0px, transparent 1px, transparent 60px, rgba(76, 175, 80, 0.02) 61px);
    z-index: -2;
}

body::after {
    content: '🌾 🥕 🥬 🍅 🌽 🥦 🥒 🧅 🥔 🍆 🫑 🥗 🌱';
    position: fixed;
    top: 40px;
    left: 0;
    width: 200%;
    text-align: center;
    font-size: 42px;
    opacity: 0.06;
    letter-spacing: 60px;
    z-index: -1;
    animation: slideVeggies 40s linear infinite;
}

@keyframes slideVeggies {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

/* Floating elements */
.floating-element {
    position: fixed;
    font-size: 30px;
    opacity: 0.1;
    animation: float 20s ease-in-out infinite;
    z-index: -1;
}

.floating-element:nth-child(1) { top: 10%; left: 10%; animation-delay: 0s; }
.floating-element:nth-child(2) { top: 20%; right: 15%; animation-delay: 3s; }
.floating-element:nth-child(3) { top: 60%; left: 5%; animation-delay: 6s; }
.floating-element:nth-child(4) { top: 70%; right: 10%; animation-delay: 9s; }

@keyframes float {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    25% { transform: translateY(-20px) rotate(5deg); }
    50% { transform: translateY(-10px) rotate(-5deg); }
    75% { transform: translateY(-30px) rotate(3deg); }
}

.dashboard-container {
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 20px;
    position: relative;
    z-index: 1;
}

/* Enhanced Dashboard Header */
.dashboard-header {
    background: linear-gradient(135deg, #16a34a 0%, #15803d 50%, #14532d 100%);
    color: white;
    padding: 40px;
    border-radius: 20px 20px 0 0;
    box-shadow: 0 8px 32px rgba(22, 163, 74, 0.3);
    position: relative;
    overflow: hidden;
}

.dashboard-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
    border-radius: 50%;
    animation: pulse-glow 4s ease-in-out infinite;
}

.dashboard-header::after {
    content: '';
    position: absolute;
    bottom: -50%;
    left: -5%;
    width: 250px;
    height: 250px;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
    border-radius: 50%;
    animation: pulse-glow 5s ease-in-out infinite;
    animation-delay: 1s;
}

@keyframes pulse-glow {
    0%, 100% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.2); opacity: 0.8; }
}

.dashboard-header > div {
    position: relative;
    z-index: 1;
}

.dashboard-header h3 {
    margin: 0 0 12px 0;
    font-size: 32px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.dashboard-header h3 span {
    font-size: 36px;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
}

.farmer-info {
    color: rgba(255,255,255,0.95);
    font-size: 15px;
    display: flex;
    gap: 28px;
    flex-wrap: wrap;
}

.farmer-info-item {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.1);
    padding: 8px 16px;
    border-radius: 20px;
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
}

.farmer-info-item:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
}

.header-actions {
    display: flex;
    gap: 12px;
    align-items: center;
}

.messages-link {
    background: rgba(255, 255, 255, 0.15);
    padding: 12px 24px;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    font-weight: 600;
    font-size: 15px;
    transition: all 0.3s ease;
    white-space: nowrap;
    display: flex;
    align-items: center;
    gap: 8px;
    position: relative;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(255, 255, 255, 0.2);
}

.messages-link:hover {
    background: rgba(255, 255, 255, 0.25);
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
    color: white;
}

.unread-badge {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    color: white;
    border-radius: 16px;
    padding: 3px 10px;
    font-size: 12px;
    font-weight: 700;
    min-width: 22px;
    text-align: center;
    animation: pulse-badge 2s infinite;
    box-shadow: 0 2px 8px rgba(239, 68, 68, 0.4);
}

@keyframes pulse-badge {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.15); }
}

.logout-link {
    background: rgba(255, 255, 255, 0.15);
    padding: 12px 24px;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    font-weight: 600;
    font-size: 15px;
    transition: all 0.3s ease;
    white-space: nowrap;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(255, 255, 255, 0.2);
}

.logout-link:hover {
    background: rgba(255, 255, 255, 0.25);
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
    color: white;
}

/* Enhanced Dashboard Content */
.dashboard-content {
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(20px);
    border-left: 1px solid rgba(224, 224, 224, 0.5);
    border-right: 1px solid rgba(224, 224, 224, 0.5);
    border-bottom: 1px solid rgba(224, 224, 224, 0.5);
    border-radius: 0 0 20px 20px;
    padding: 40px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
}

/* Enhanced Quick Stats */
.quick-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.stat-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8fef9 100%);
    padding: 28px 24px;
    border-radius: 16px;
    border: 2px solid #dcfce7;
    text-align: center;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(22, 163, 74, 0.08);
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #22c55e 0%, #16a34a 50%, #15803d 100%);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.stat-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 12px 28px rgba(22, 163, 74, 0.2);
    border-color: #86efac;
}

.stat-card:hover::before {
    transform: scaleX(1);
}

.stat-value {
    font-size: 42px;
    font-weight: 800;
    background: linear-gradient(135deg, #15803d 0%, #22c55e 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 8px;
    animation: fadeInUp 0.6s ease;
}

.stat-label {
    font-size: 14px;
    color: #666;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.section {
    margin-bottom: 48px;
}

.section-title {
    font-size: 24px;
    font-weight: 700;
    background: linear-gradient(135deg, #15803d 0%, #16a34a 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0 0 24px 0;
    padding-bottom: 16px;
    border-bottom: 3px solid #dcfce7;
    position: relative;
}

.section-title::after {
    content: '';
    position: absolute;
    bottom: -3px;
    left: 0;
    width: 80px;
    height: 3px;
    background: linear-gradient(90deg, #16a34a 0%, transparent 100%);
}

/* Enhanced Add Product Form */
.add-product-form {
    background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
    padding: 32px;
    border-radius: 16px;
    border: 2px solid #dcfce7;
    box-shadow: 0 4px 20px rgba(22, 163, 74, 0.08);
    transition: all 0.3s ease;
}

.add-product-form:hover {
    box-shadow: 0 8px 32px rgba(22, 163, 74, 0.15);
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 24px;
}

.form-field {
    display: flex;
    flex-direction: column;
}

.form-field.full-width {
    grid-column: 1 / -1;
}

.form-field label {
    font-weight: 600;
    color: #15803d;
    margin-bottom: 10px;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.form-field input,
.form-field textarea {
    padding: 14px 18px;
    border: 2px solid #dcfce7;
    border-radius: 10px;
    font-size: 15px;
    transition: all 0.3s ease;
    font-family: inherit;
    background: white;
}

.form-field textarea {
    resize: vertical;
    min-height: 100px;
}

.form-field input:focus,
.form-field textarea:focus {
    outline: none;
    border-color: #22c55e;
    box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.1);
    transform: translateY(-2px);
}

.add-button {
    padding: 14px 40px;
    background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(22, 163, 74, 0.3);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.add-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(22, 163, 74, 0.4);
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
}

.add-button:active {
    transform: translateY(-1px);
}

/* Enhanced Product Cards */
.products-list {
    display: grid;
    gap: 20px;
}

.product-card {
    background: linear-gradient(135deg, #ffffff 0%, #fafafa 100%);
    border: 2px solid #dcfce7;
    border-radius: 16px;
    padding: 24px;
    display: flex;
    gap: 24px;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 4px 12px rgba(22, 163, 74, 0.08);
    position: relative;
    overflow: hidden;
}

.product-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(180deg, #22c55e 0%, #16a34a 100%);
    opacity: 0;
    transition: opacity 0.4s ease;
}

.product-card:hover {
    box-shadow: 0 12px 32px rgba(22, 163, 74, 0.18);
    transform: translateY(-6px);
    border-color: #86efac;
}

.product-card:hover::before {
    opacity: 1;
}

.product-details {
    flex: 1;
}

.product-name {
    font-size: 20px;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 10px;
}

.product-description {
    color: #666;
    font-size: 14px;
    margin-bottom: 16px;
    line-height: 1.6;
}

.product-meta {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    font-size: 14px;
    color: #555;
    margin-bottom: 12px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 6px;
    background: #f5f5f5;
    padding: 6px 12px;
    border-radius: 8px;
    font-weight: 600;
}

.product-contact {
    color: #16a34a;
    font-weight: 600;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.product-actions {
    display: flex;
    flex-direction: column;
    gap: 16px;
    align-items: flex-end;
}

.product-image {
    width: 160px;
    height: 160px;
    object-fit: cover;
    border-radius: 12px;
    border: 3px solid #f5f5f5;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}

.product-card:hover .product-image {
    transform: scale(1.05) rotate(2deg);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

.action-buttons {
    display: flex;
    gap: 10px;
}

.btn {
    padding: 10px 18px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.btn-edit {
    background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color: white;
}

.btn-edit:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(34, 197, 94, 0.4);
}

.btn-delete {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    color: white;
}

.btn-delete:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
}

.btn-sold {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
}

.btn-sold:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
}

.btn-available {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
}

.btn-available:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
}

.status-badge {
    display: inline-block;
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 12px;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.status-available {
    background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
    color: #065f46;
}

.status-sold {
    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
    color: #991b1b;
}

.empty-state {
    text-align: center;
    padding: 60px 40px;
    color: #999;
    background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
    border-radius: 16px;
    border: 3px dashed #bbf7d0;
}

.empty-state > div:first-child {
    font-size: 64px;
    margin-bottom: 16px;
    animation: float 3s ease-in-out infinite;
}

@media (max-width: 768px) {
    .dashboard-header > div {
        flex-direction: column;
        gap: 20px;
        align-items: flex-start !important;
    }
    
    .header-actions {
        width: 100%;
        flex-direction: column;
    }
    
    .messages-link,
    .logout-link {
        width: 100%;
        text-align: center;
        justify-content: center;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .product-card {
        flex-direction: column;
    }
    
    .product-image {
        width: 100%;
        height: 220px;
    }
    
    .product-actions {
        flex-direction: row;
        width: 100%;
    }
    
    .action-buttons {
        width: 100%;
    }
    
    .btn {
        flex: 1;
        font-size: 12px;
        padding: 10px 12px;
    }
    
    .farmer-info {
        flex-direction: column;
        gap: 10px;
    }
    
    .quick-stats {
        grid-template-columns: 1fr;
    }
    
    .dashboard-header h3 {
        font-size: 26px;
    }
}
</style>

<div class="floating-element">🌾</div>
<div class="floating-element">🥕</div>
<div class="floating-element">🌽</div>
<div class="floating-element">🍅</div>

<div class="dashboard-container">
    <div class="dashboard-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h3><span>🌾</span> <?=h($farmer['name'] ?? $farmer['first_name'] . ' ' . $farmer['last_name'])?></h3>
                <div class="farmer-info">
                    <div class="farmer-info-item">
                        <span>🏡</span>
                        <span><?=h($farmer['farm_name'] ?: 'No farm name')?></span>
                    </div>
                    <div class="farmer-info-item">
                        <span>📞</span>
                        <span><?=h($farmer['phone'])?></span>
                    </div>
                </div>
            </div>
            <div class="header-actions">
                <a href="farmer_messages.php" class="messages-link">
                    <span>💬</span>
                    <span>Messages</span>
                    <?php if($unread_count > 0): ?>
                        <span class="unread-badge"><?= $unread_count ?></span>
                    <?php endif; ?>
                </a>
                <a href="logout.php" class="logout-link">
                    <span>🚪</span>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>

    <div class="dashboard-content">
        <?php
        // Get product stats
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(*) as total_products,
                SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available_products,
                SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END) as sold_products
            FROM products 
            WHERE farmer_id = ?
        ");
        $stmt->execute([$_SESSION['farmer_id']]);
        $stats = $stmt->fetch();
        ?>
        
        <div class="quick-stats">
            <div class="stat-card">
                <div class="stat-value"><?= $stats['total_products'] ?></div>
                <div class="stat-label">Total Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $stats['available_products'] ?></div>
                <div class="stat-label">Available</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $stats['sold_products'] ?></div>
                <div class="stat-label">Sold</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $unread_count ?></div>
                <div class="stat-label">Unread Messages</div>
            </div>
        </div>
        
        <div class="section">
            <h4 class="section-title">➕ Add New Product</h4>
            <form method="post" enctype="multipart/form-data" class="add-product-form">
                <div class="form-grid">
                    <div class="form-field">
                        <label>🏷️ Product Name *</label>
                        <input name="product_name" placeholder="e.g., Fresh Tomatoes" required>
                    </div>
                    
                    <div class="form-field">
                        <label>💰 Price per Kilo (₱) *</label>
                        <input name="price" type="number" step="0.01" placeholder="e.g., 50.00" required>
                    </div>
                    
                    <div class="form-field full-width">
                        <label>📝 Description</label>
                        <textarea name="description" placeholder="Brief description of your product"></textarea>
                    </div>
                    
                    <div class="form-field">
                        <label>📦 Available Quantity (kg) *</label>
                        <input name="quantity" type="number" step="0.01" placeholder="e.g., 50" required>
                    </div>
                    
                    <div class="form-field">
                        <label>📞 Contact Phone *</label>
                        <input name="contact_phone" type="tel" placeholder="+63 912 345 6789" value="<?=h($farmer['phone'])?>" required>
                    </div>
                    
                    <div class="form-field full-width">
                        <label>📸 Product Image (optional)</label>
                        <input type="file" name="image" accept="image/*">
                    </div>
                </div>
                
                <button name="add_product" class="add-button">Add Product</button>
            </form>
        </div>

        <div class="section">
            <h4 class="section-title">📦 Your Products</h4>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM products WHERE farmer_id=? ORDER BY id DESC"); 
            $stmt->execute([$_SESSION['farmer_id']]); 
            $prods = $stmt->fetchAll(); 
            
            if(!$prods): ?>
                <div class="empty-state">
                    <div style="font-size: 64px; margin-bottom: 16px;">🥕</div>
                    <p style="font-size: 18px; margin: 0;">No products yet. Add your first product above!</p>
                </div>
            <?php else: ?>
                <div class="products-list">
                    <?php foreach($prods as $p): ?>
                        <div class="product-card">
                            <div class="product-details">
                                <?php 
                                $status = $p['status'] ?? 'available';
                                if($status === 'sold'): ?>
                                    <span class="status-badge status-sold">🔴 Sold</span>
                                <?php else: ?>
                                    <span class="status-badge status-available">🟢 Available</span>
                                <?php endif; ?>
                                
                                <div class="product-name"><?=h($p['name'])?></div>
                                <div class="product-description"><?=h($p['description'])?></div>
                                <div class="product-meta">
                                    <div class="meta-item">
                                        <span>💰</span>
                                        <span>₱<?=number_format($p['price'],2)?>/kg</span>
                                    </div>
                                    <div class="meta-item">
                                        <span>📦</span>
                                        <span><?=number_format($p['quantity'],2)?> kg available</span>
                                    </div>
                                </div>
                                <div class="product-contact">
                                    📞 <?=h($p['contact_phone'])?>
                                </div>
                            </div>
                            
                            <div class="product-actions">
                                <?php if($p['image'] && file_exists($p['image'])): ?>
                                    <img src="<?=h($p['image'])?>" alt="<?=h($p['name'])?>" class="product-image">
                                <?php endif; ?>
                                
                                <div class="action-buttons">
                                    <form method="get" action="edit.php" style="display:inline;">
                                        <input type="hidden" name="id" value="<?=h($p['id'])?>">
                                        <button type="submit" class="btn btn-edit">Edit</button>
                                    </form>
                                    
                                    <?php 
                                    $status = $p['status'] ?? 'available';
                                    if($status === 'available'): ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="product_id" value="<?=h($p['id'])?>">
                                            <button name="mark_sold" class="btn btn-sold" onclick="return confirm('Mark this product as sold?')">Mark Sold</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="product_id" value="<?=h($p['id'])?>">
                                            <button name="mark_available" class="btn btn-available">Mark Available</button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="product_id" value="<?=h($p['id'])?>">
                                        <button name="delete_product" class="btn btn-delete" onclick="return confirm('Delete this product?')">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>