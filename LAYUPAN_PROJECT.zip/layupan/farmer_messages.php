<?php
require 'config.php';

// Check if farmer is logged in
if (!isset($_SESSION['farmer_id'])) {
    header('Location: farmerlogin.php');
    exit;
}

$farmer_id = $_SESSION['farmer_id'];
$customer_phone = $_GET['phone'] ?? null;

// Handle message sending BEFORE including header.php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && $customer_phone) {
    $message = trim($_POST['message']);
    
    if (!empty($message)) {
        try {
            // Get customer name from existing messages
            $stmt = $pdo->prepare("SELECT customer_name FROM messages WHERE customer_phone = ? AND farmer_id = ? LIMIT 1");
            $stmt->execute([$customer_phone, $farmer_id]);
            $customer_name = $stmt->fetchColumn();
            
            if ($customer_name) {
                // Get product_id from the conversation if it exists
                $stmt = $pdo->prepare("SELECT product_id FROM messages WHERE customer_phone = ? AND farmer_id = ? AND product_id IS NOT NULL LIMIT 1");
                $stmt->execute([$customer_phone, $farmer_id]);
                $product_id_from_conv = $stmt->fetchColumn();
                
                // Insert farmer's reply
                $stmt = $pdo->prepare("
                    INSERT INTO messages (customer_phone, customer_name, farmer_id, sender_type, message, product_id, is_read, created_at) 
                    VALUES (?, ?, ?, 'farmer', ?, ?, 1, NOW())
                ");
                $stmt->execute([$customer_phone, $customer_name, $farmer_id, $message, $product_id_from_conv]);
                
                // Redirect to prevent form resubmission
                header("Location: farmer_messages.php?phone=" . urlencode($customer_phone));
                exit;
            }
        } catch (PDOException $e) {
            $error_message = "Error sending message: " . $e->getMessage();
        }
    }
}

// Now include header after all redirects are done
require 'header.php';

// Get all unique customers who have messaged this farmer
$stmt = $pdo->prepare("
    SELECT 
        customer_phone,
        customer_name,
        MAX(created_at) as last_message_time,
        COUNT(CASE WHEN sender_type = 'customer' AND is_read = 0 THEN 1 END) as unread_count,
        (SELECT message FROM messages WHERE customer_phone = m.customer_phone AND farmer_id = ? ORDER BY created_at DESC LIMIT 1) as last_message
    FROM messages m
    WHERE farmer_id = ?
    GROUP BY customer_phone, customer_name
    ORDER BY last_message_time DESC
");
$stmt->execute([$farmer_id, $farmer_id]);
$conversations = $stmt->fetchAll();

// Get messages for selected customer
$messages = [];
$selected_customer = null;
if ($customer_phone) {
    $stmt = $pdo->prepare("
        SELECT m.*, p.name as product_name
        FROM messages m
        LEFT JOIN products p ON m.product_id = p.id
        WHERE m.customer_phone = ? AND m.farmer_id = ?
        ORDER BY m.created_at ASC
    ");
    $stmt->execute([$customer_phone, $farmer_id]);
    $messages = $stmt->fetchAll();
    
    // Mark messages as read
    $stmt = $pdo->prepare("
        UPDATE messages 
        SET is_read = 1 
        WHERE customer_phone = ? AND farmer_id = ? AND sender_type = 'customer' AND is_read = 0
    ");
    $stmt->execute([$customer_phone, $farmer_id]);
    
    // Get customer info
    if (!empty($messages)) {
        $selected_customer = [
            'phone' => $customer_phone,
            'name' => $messages[0]['customer_name']
        ];
    }
}

// Count total unread messages
$stmt = $pdo->prepare("
    SELECT COUNT(*) as total_unread
    FROM messages
    WHERE farmer_id = ? AND sender_type = 'customer' AND is_read = 0
");
$stmt->execute([$farmer_id]);
$total_unread = $stmt->fetch()['total_unread'];

// Helper function for HTML escaping
if (!function_exists('h')) {
    function h($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}
?>

<style>
body {
    margin: 0;
    background: linear-gradient(to bottom, #e8f5e9 0%, #f1f8f4 50%, #fff8e1 100%);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    min-height: 100vh;
}

.messages-container {
    display: flex;
    height: calc(100vh - 80px);
    max-width: 1400px;
    margin: 20px auto;
    background: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    border-radius: 12px;
    overflow: hidden;
}

.conversations-sidebar {
    width: 350px;
    border-right: 1px solid #e0e0e0;
    display: flex;
    flex-direction: column;
    background: #fafafa;
}

.sidebar-header {
    padding: 20px;
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
}

.sidebar-header h2 {
    margin: 0 0 8px 0;
    font-size: 20px;
    font-weight: 600;
}

.sidebar-header p {
    margin: 0;
    font-size: 14px;
    opacity: 0.9;
}

.back-to-dashboard {
    background: rgba(255,255,255,0.2);
    padding: 8px 16px;
    border-radius: 6px;
    color: white;
    text-decoration: none;
    font-size: 13px;
    display: inline-block;
    margin-top: 12px;
    transition: all 0.2s;
}

.back-to-dashboard:hover {
    background: rgba(255,255,255,0.3);
}

.conversations-list {
    flex: 1;
    overflow-y: auto;
}

.conversation-item {
    padding: 16px 20px;
    border-bottom: 1px solid #e8e8e8;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    color: inherit;
    display: block;
    position: relative;
}

.conversation-item:hover {
    background: #f0f7ed;
}

.conversation-item.active {
    background: #e8f5e9;
    border-left: 4px solid #6aa84f;
}

.conversation-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 4px;
}

.customer-name {
    font-weight: 600;
    font-size: 15px;
    color: #1a1a1a;
    display: flex;
    align-items: center;
    gap: 8px;
}

.customer-phone {
    font-size: 12px;
    color: #666;
}

.conversation-time {
    font-size: 11px;
    color: #999;
}

.last-message {
    font-size: 13px;
    color: #666;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-top: 4px;
}

.unread-badge {
    background: #ef4444;
    color: white;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 11px;
    font-weight: 600;
    margin-left: 8px;
}

.chat-area {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.chat-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e0e0e0;
    background: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.chat-customer-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.chat-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    font-weight: 600;
}

.chat-customer-details h3 {
    margin: 0 0 4px 0;
    font-size: 18px;
    font-weight: 600;
}

.chat-customer-details p {
    margin: 0;
    font-size: 14px;
    color: #666;
}

.chat-messages {
    flex: 1;
    padding: 24px;
    overflow-y: auto;
    background: #fafafa;
}

.message {
    display: flex;
    margin-bottom: 16px;
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.message-content {
    max-width: 70%;
    padding: 12px 16px;
    border-radius: 12px;
    position: relative;
    word-wrap: break-word;
}

.message.customer {
    justify-content: flex-start;
}

.message.customer .message-content {
    background: white;
    color: #1a1a1a;
    border-bottom-left-radius: 4px;
    border: 1px solid #e0e0e0;
}

.message.farmer {
    justify-content: flex-end;
}

.message.farmer .message-content {
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    border-bottom-right-radius: 4px;
}

.message-text {
    line-height: 1.5;
    font-size: 14px;
}

.message-time {
    font-size: 11px;
    opacity: 0.7;
    margin-top: 4px;
}

.message.farmer .message-time {
    text-align: right;
}

.product-reference {
    background: rgba(255, 255, 255, 0.2);
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 12px;
    margin-bottom: 8px;
    border-left: 3px solid rgba(255, 255, 255, 0.5);
}

.message.customer .product-reference {
    background: #f0f7ed;
    color: #2e7d32;
    border-left-color: #6aa84f;
}

.chat-input-area {
    padding: 20px 24px;
    border-top: 1px solid #e0e0e0;
    background: white;
}

.chat-input-form {
    display: flex;
    gap: 12px;
    align-items: flex-end;
}

.chat-textarea {
    flex: 1;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 14px;
    font-family: inherit;
    resize: none;
    min-height: 44px;
    max-height: 120px;
    transition: all 0.2s;
}

.chat-textarea:focus {
    outline: none;
    border-color: #6aa84f;
    box-shadow: 0 0 0 3px rgba(106, 168, 79, 0.1);
}

.send-button {
    padding: 12px 24px;
    background: linear-gradient(135deg, #6aa84f 0%, #5a923f 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.send-button:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(106, 168, 79, 0.3);
}

.send-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.empty-state {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: #999;
    padding: 40px;
}

.empty-state-icon {
    font-size: 64px;
    margin-bottom: 16px;
}

.no-conversations {
    text-align: center;
    padding: 40px 20px;
    color: #999;
}

.error-message {
    background: #fee;
    color: #c33;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 12px;
    border-left: 4px solid #c33;
}

@media (max-width: 768px) {
    .messages-container {
        flex-direction: column;
        height: auto;
        min-height: calc(100vh - 100px);
        margin: 10px;
    }
    
    .conversations-sidebar {
        width: 100%;
        border-right: none;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .chat-area {
        display: <?= $customer_phone ? 'flex' : 'none' ?>;
        height: calc(100vh - 100px);
    }
    
    .conversations-list {
        display: <?= $customer_phone ? 'none' : 'block' ?>;
        max-height: 400px;
    }
    
    .chat-header {
        flex-direction: column;
        gap: 12px;
        align-items: flex-start;
    }
}

.conversations-list::-webkit-scrollbar,
.chat-messages::-webkit-scrollbar {
    width: 8px;
}

.conversations-list::-webkit-scrollbar-track,
.chat-messages::-webkit-scrollbar-track {
    background: #f1f1f1;
}

.conversations-list::-webkit-scrollbar-thumb,
.chat-messages::-webkit-scrollbar-thumb {
    background: #c8e6c9;
    border-radius: 4px;
}
</style>

<div class="messages-container">
    <!-- Conversations Sidebar -->
    <div class="conversations-sidebar">
        <div class="sidebar-header">
            <h2>💬 Messages</h2>
            <p><?= count($conversations) ?> conversation<?= count($conversations) !== 1 ? 's' : '' ?>
                <?php if ($total_unread > 0): ?>
                    • <?= $total_unread ?> unread
                <?php endif; ?>
            </p>
            <a href="farmerdashboard.php" class="back-to-dashboard">← Back to Dashboard</a>
        </div>
        
        <div class="conversations-list">
            <?php if (empty($conversations)): ?>
                <div class="no-conversations">
                    <div style="font-size: 48px; margin-bottom: 12px;">📭</div>
                    <p><strong>No messages yet</strong></p>
                    <p style="font-size: 13px; margin-top: 8px;">Customers can message you from your product listings</p>
                </div>
            <?php else: ?>
                <?php foreach ($conversations as $conv): ?>
                    <a href="farmer_messages.php?phone=<?= h($conv['customer_phone']) ?>" 
                       class="conversation-item <?= $customer_phone === $conv['customer_phone'] ? 'active' : '' ?>">
                        <div class="conversation-header">
                            <div class="customer-name">
                                <span>👤</span>
                                <span><?= h($conv['customer_name']) ?></span>
                                <?php if ($conv['unread_count'] > 0): ?>
                                    <span class="unread-badge"><?= $conv['unread_count'] ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="conversation-time">
                                <?php
                                $time = strtotime($conv['last_message_time']);
                                $now = time();
                                $diff = $now - $time;
                                
                                if ($diff < 60) {
                                    echo 'Just now';
                                } elseif ($diff < 3600) {
                                    echo floor($diff / 60) . 'm ago';
                                } elseif ($diff < 86400) {
                                    echo floor($diff / 3600) . 'h ago';
                                } else {
                                    echo date('M j', $time);
                                }
                                ?>
                            </div>
                        </div>
                        <div class="customer-phone">📞 <?= h($conv['customer_phone']) ?></div>
                        <div class="last-message"><?= h($conv['last_message']) ?></div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Chat Area -->
    <div class="chat-area">
        <?php if ($customer_phone && $selected_customer): ?>
            <div class="chat-header">
                <div class="chat-customer-info">
                    <div class="chat-avatar">
                        <?= strtoupper(substr($selected_customer['name'], 0, 1)) ?>
                    </div>
                    <div class="chat-customer-details">
                        <h3><?= h($selected_customer['name']) ?></h3>
                        <p>📞 <?= h($selected_customer['phone']) ?> • 
                           <a href="tel:<?= h($selected_customer['phone']) ?>" style="color: #6aa84f; text-decoration: none; font-weight: 600;">Call Now</a>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="chat-messages" id="chatMessages">
                <?php if (isset($error_message)): ?>
                    <div class="error-message"><?= h($error_message) ?></div>
                <?php endif; ?>
                
                <?php if (empty($messages)): ?>
                    <div class="empty-state">
                        <div>
                            <div class="empty-state-icon">💬</div>
                            <p><strong>No messages yet</strong></p>
                            <p style="font-size: 14px; margin-top: 8px;">Start the conversation with <?= h($selected_customer['name']) ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($messages as $msg): ?>
                        <div class="message <?= h($msg['sender_type']) ?>">
                            <div class="message-content">
                                <?php if ($msg['product_id'] && $msg['product_name']): ?>
                                    <div class="product-reference">
                                        📦 Product
                                    : <?= h($msg['product_name']) ?>
                                    </div>
                                <?php endif; ?>
                                <div class="message-text"><?= nl2br(h($msg['message'])) ?></div>
                                <div class="message-time">
                                    <?= date('M j, g:i A', strtotime($msg['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div class="chat-input-area">
                <form method="POST" action="farmer_messages.php?phone=<?= urlencode($customer_phone) ?>" class="chat-input-form" id="chatForm">
                    <textarea 
                        name="message" 
                        class="chat-textarea" 
                        placeholder="Type your reply..."
                        required
                        rows="1"
                        id="messageInput"
                    ></textarea>
                    <button type="submit" class="send-button" id="sendButton">
                        <span>📤</span>
                        <span>Send</span>
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div>
                    <div class="empty-state-icon">💬</div>
                    <p><strong>Select a conversation</strong></p>
                    <p style="font-size: 14px; margin-top: 8px;">Choose a customer from the left to view and reply to messages</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
<?php if ($customer_phone): ?>
const textarea = document.getElementById('messageInput');
const chatMessages = document.getElementById('chatMessages');
const sendButton = document.getElementById('sendButton');
const chatForm = document.getElementById('chatForm');

if (textarea) {
    // Auto-resize textarea
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    
    // Send on Enter (Shift+Enter for new line)
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (this.value.trim()) {
                chatForm.submit();
            }
        }
    });
}

// Disable send button on submit to prevent double-submission
if (chatForm) {
    chatForm.addEventListener('submit', function(e) {
        if (sendButton.disabled) {
            e.preventDefault();
            return false;
        }
        sendButton.disabled = true;
        sendButton.innerHTML = '<span>⏳</span><span>Sending...</span>';
    });
}

// Auto-scroll to bottom
if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Auto-refresh messages every 5 seconds
setInterval(function() {
    if (document.activeElement !== textarea) {
        const scrollAtBottom = Math.abs(chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight) < 50;
        
        fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newMessages = doc.getElementById('chatMessages');
                
                if (newMessages && newMessages.innerHTML !== chatMessages.innerHTML) {
                    chatMessages.innerHTML = newMessages.innerHTML;
                    if (scrollAtBottom) {
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    }
                }
            })
            .catch(err => console.error('Error refreshing messages:', err));
    }
}, 5000);
<?php endif; ?>
</script>

<?php require 'footer.php'; ?>